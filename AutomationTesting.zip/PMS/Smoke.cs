using NUnit.Framework;
using AgilysysTests;
using PMS.Scripts;

namespace Reservation
{

    [TestFixture]
    public class Smoke : BaseNunitInitialize
    {
        ApiTestScripts apiTestScripts = new ApiTestScripts();

        [Test]
        [Category("SmokeTest")]
        public void LoginPMS()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            reservationScripts.LoginPMS();
        }

        
        [Test]
        [Category("Reservation")]
        public void ValidateReservationDetails()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            reservationScripts.LoginPMS();
            string confirmationNumber = apiTestScripts.CreateReservationViaApi();
            reservationScripts.ValidateReservation(confirmationNumber);

        }

        [Test]
        [Category("SmokeTest")]
        public void CreateReservation()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            reservationScripts.LoginPMS();
            reservationScripts.CreateReservation();

        }

        [Test]
        [Category("Reservation")]
        public void ViewReservation()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            ApiTestScripts apiTestScripts = new ApiTestScripts();
            reservationScripts.LoginPMS();
            string confirmationNumber = apiTestScripts.CreateReservationViaApi();
            reservationScripts.ViewReservation(confirmationNumber);

        }

        [Test]
        [Category("Reservation")]
        public void EditReservation()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            reservationScripts.LoginPMS();
            string confirmationNumber = apiTestScripts.CreateReservationViaApi();
            reservationScripts.EditReservation(confirmationNumber);

        }

        [Test]
        [Category("SmokeTest")]
        public void CheckInCheckOutReservation()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            reservationScripts.LoginPMS();
            string confirmationNumber = apiTestScripts.CreateReservationViaApi();
            reservationScripts.CheckInReservation(confirmationNumber);
            reservationScripts.CheckOutReservation(confirmationNumber);

        }

        [Test]
        [Category("Guest")]
        public void CreateAndEditGuest()
        {
            AddReport();

            GuestScripts guestScripts = new GuestScripts();
            guestScripts.LoginPMS();
            guestScripts.CreateNewGuest();
            guestScripts.CheckAddedGuest();
            guestScripts.EditGuest();
            guestScripts.CheckUpdatedGuest();

        }

        [Test]
        [Category("Settings")]
        public void CreateAndtDeleteRoom()
        {
            AddReport();

            SettingsScripts settingsScripts = new SettingsScripts();
            settingsScripts.LoginPMS();
            string roomNum = "AUTO";
            settingsScripts.CreateRoom(roomNum);
            settingsScripts.DeleteRoom(roomNum);

        }

        [Test]
        [Category("SmokeTest")]
        public void ReservationFolioPosting()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            reservationScripts.LoginPMS();
            string confirmationNumber = apiTestScripts.CreateReservationViaApi();
            reservationScripts.FolioPosting(confirmationNumber);

        }

        [Test]
        [Category("Reservation")]
        public void CopyThisStay()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            reservationScripts.LoginPMS();
            string confirmationNumber = apiTestScripts.CreateReservationViaApi();
            string copiedToResNum = reservationScripts.CopyStay(confirmationNumber);
            reservationScripts.ValidateReservation(copiedToResNum);
        }

        [Test]
        [Category("Reservation")]
        public void TransferTheStay()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            reservationScripts.LoginPMS();
            string confirmationNumber = apiTestScripts.CreateReservationViaApi();
            reservationScripts.TransferStay(confirmationNumber);

        }

        [Test]
        [Category("Reservation")]
        public void AddAdditionalNames()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            reservationScripts.LoginPMS();
            string confirmationNumber = apiTestScripts.CreateReservationViaApi();
            reservationScripts.AddAdditionalNames(confirmationNumber);

        }


    }
}