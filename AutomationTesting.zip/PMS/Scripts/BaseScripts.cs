﻿using AgilysysTests;
using AgilysysTests.Common;
using AgilysysTests.Configurations;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;
using PMS.Pages.Common;
using PMS.Pages.Home;
using PMS.Pages.Reservation;
using System;
using System.Threading;

namespace PMS.Scripts
{
    public class BaseScripts : BaseNunitInitialize
    {
        public void LoginPMS()
        {            
            WebDriver.Driver.Navigate().GoToUrl(Settings.PMSUrl);
            Assert.AreEqual("PMS", WebDriver.Driver.Title);

            var loginPage = new LoginPage();
            Assert.AreEqual("Login", loginPage.LoginLabel.Text);
            WebDriverWait wait = new WebDriverWait(WebDriver.Driver, TimeSpan.FromSeconds(Settings.ElementTimeout));
            wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("button.login__btn")));
            Router.Click(loginPage.LoginButton);
            Router.Sendkeys(loginPage.UserNameInput, Settings.Username);
            Router.Sendkeys(loginPage.PasswordInput, Settings.Password);
            Router.Sendkeys(loginPage.CustomerIdInput, Settings.CustomerId);
            Router.Click(loginPage.RememberMeCheckBox);
            AngularUtils.WaitUntilClickable(loginPage.LoginButton);
            Router.Click(loginPage.LoginButton);
            //Router.DropDownSelect(loginPage.LocationSelect, "PMS FOLIO");
            //Router.Click(loginPage.EnterButton);

            var homepage = new HomePage();
            StringAssert.Contains("PMS", WebDriver.Driver.Title);
            Router.Click(homepage.ReservationsTab);
        }

        public void SearchAndViewReservation(string resNumber)
        {
            var reservationsListPage = new ReservationsListPage();
            Router.Sendkeys(reservationsListPage.SearchBoxInput, resNumber);
            Assert.AreEqual(resNumber, reservationsListPage.ReservationListDetail("confirmationNumber").Text);
            Router.Click(reservationsListPage.ReservationListDetail("confirmationNumber"));
            Thread.Sleep(TimeSpan.FromSeconds(5));

        }
    }
}
