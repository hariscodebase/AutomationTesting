﻿using AgilysysTests;
using NUnit.Framework;
using PMS.Pages.Home;
using PMS.Pages.PMSSettings;
using System;
using System.Threading;

namespace PMS.Scripts
{
    public class SettingsScripts : BaseScripts
    {

        public void CreateRoom(string roomNum)
        {
            var homePage = new HomePage();
            Router.Click(homePage.DotsButton);
            Router.Click(homePage.SettingsTab);
            var setUpPage = new SetUpPage();
            Router.Click(setUpPage.AsidePanelOptions("Room Definitions"));
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Click(setUpPage.CreateRoomButton);

            var roomSpecificationsPage = new RoomSpecificationsPage();
            Router.Sendkeys(roomSpecificationsPage.RoomNumberInput, roomNum);
            Router.Click(roomSpecificationsPage.BeddedCheckBox);
            Router.DropDownSelect(roomSpecificationsPage.RoomTypeDropDown, "KNS");
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Click(roomSpecificationsPage.CreateButton);
            
            AngularUtils.WaitUntilClickable(setUpPage.SearchByInput);
            Router.Sendkeys(setUpPage.SearchByInput, roomNum);
            Thread.Sleep(TimeSpan.FromSeconds(5));
            //Assert.AreEqual(roomNum, setUpPage.ValidateRoomSetupDetail("room").Text);

        }

        public void EditRoom(string roomNum)
        {
            var setUpPage = new SetUpPage();
            Router.Sendkeys(setUpPage.SearchByInput, roomNum);
            Router.Click(setUpPage.EditIcon);

            var roomSpecificationsPage = new RoomSpecificationsPage();
            Router.DropDownSelect(roomSpecificationsPage.RoomTypeDropDown, "Single");
            Router.Click(roomSpecificationsPage.UpdateButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Sendkeys(setUpPage.SearchByInput, roomNum);
            Assert.AreEqual("SNG", setUpPage.ValidateRoomSetupDetail("roomType").Text);

        }

        public void DeleteRoom(string roomNum)
        {
            var setUpPage = new SetUpPage();
            Router.Sendkeys(setUpPage.SearchByInput, roomNum);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Click(setUpPage.DeleteIcon);
            Router.Click(setUpPage.PopUpYesButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Sendkeys(setUpPage.SearchByInput, roomNum);
            Assert.IsTrue(setUpPage.NoDataFoundLabel.Displayed);

            }

        public void CreateRoomFeature(string roomFeatureCode)
        {
            var homePage = new HomePage();
            Router.Click(homePage.DotsButton);
            Router.Click(homePage.SettingsTab);
            var setUpPage = new SetUpPage();
            Router.Click(setUpPage.AsidePanelOptions("Room Features"));
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Click(setUpPage.CreateRoomFeatureButton);

            var createRoomFeaturesPage = new CreateRoomFeaturesPage();
            Router.Sendkeys(createRoomFeaturesPage.RoomFeatureCodeInput, roomFeatureCode);
            Router.Sendkeys(createRoomFeaturesPage.RoomFeatureNameInput, "test room feature");
            Router.Click(createRoomFeaturesPage.CreateButton);
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Sendkeys(setUpPage.SearchByInput, roomFeatureCode);
            Assert.AreEqual(roomFeatureCode, setUpPage.ValidateRoomSetupDetail("code").Text);

        }

        public void EditRoomFeature(string roomFeatureCode)
        {
            var setUpPage = new SetUpPage();
            Router.Sendkeys(setUpPage.SearchByInput, roomFeatureCode);
            Router.Click(setUpPage.EditIcon);

            var createRoomFeaturesPage = new CreateRoomFeaturesPage();
            Router.Sendkeys(createRoomFeaturesPage.RoomFeatureNameInput, "test edit feature");
            Router.Click(createRoomFeaturesPage.UpdateButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Sendkeys(setUpPage.SearchByInput, roomFeatureCode);            
            Assert.AreEqual("test edit feature", setUpPage.ValidateRoomSetupDetail("name").Text);

        }

        public void DeleteRoomFeature(string roomFeatureCode)
        {
            var setUpPage = new SetUpPage();
            Router.Sendkeys(setUpPage.SearchByInput, roomFeatureCode);
            
            Router.Click(setUpPage.DeleteIcon);
            Router.Click(setUpPage.PopUpYesButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Sendkeys(setUpPage.SearchByInput, roomFeatureCode);
            Assert.IsTrue(setUpPage.NoDataFoundLabel.Displayed);

        }

        public void CreateRoomLocation(string roomLocationCode)
        {
            var homePage = new HomePage();
            Router.Click(homePage.DotsButton);
            Router.Click(homePage.SettingsTab);
            var setUpPage = new SetUpPage();
            Router.Click(setUpPage.AsidePanelOptions("Room Locations"));
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Click(setUpPage.CreateRoomLocationButton);

            var createRoomLocationsPage = new CreateRoomLocationsPage();
            Router.Sendkeys(createRoomLocationsPage.RoomLocationCodeInput, roomLocationCode);
            Router.Sendkeys(createRoomLocationsPage.RoomLocationNameInput, "test location");
            Router.Click(createRoomLocationsPage.CreateButton);
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Sendkeys(setUpPage.SearchByInput, roomLocationCode);
            Assert.AreEqual(roomLocationCode, setUpPage.ValidateRoomSetupDetail("code").Text);

        }

        public void EditRoomLocation(string roomLocationCode)
        {
            var setUpPage = new SetUpPage();
            Router.Sendkeys(setUpPage.SearchByInput, roomLocationCode);
            Router.Click(setUpPage.EditIcon);

            var createRoomLocationsPage = new CreateRoomLocationsPage();
            Router.Sendkeys(createRoomLocationsPage.RoomLocationNameInput, "test edit location");
            Router.Click(createRoomLocationsPage.UpdateButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Sendkeys(setUpPage.SearchByInput, roomLocationCode);
            Assert.AreEqual("test edit location", setUpPage.ValidateRoomSetupDetail("name").Text);

        }

        public void DeleteRoomLocation(string roomLocationCode)
        {
            var setUpPage = new SetUpPage();
            Router.Sendkeys(setUpPage.SearchByInput, roomLocationCode);

            Router.Click(setUpPage.DeleteIcon);
            Router.Click(setUpPage.PopUpYesButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Sendkeys(setUpPage.SearchByInput, roomLocationCode);
            Assert.IsTrue(setUpPage.NoDataFoundLabel.Displayed);

        }

        public void CreateRoomType(string roomTypeCode)
        {
            var homePage = new HomePage();
            Router.Click(homePage.DotsButton);
            Router.Click(homePage.SettingsTab);
            var setUpPage = new SetUpPage();
            Router.Click(setUpPage.AsidePanelOptions("Room Type Maintenance"));
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Click(setUpPage.CreateRoomTypeButton);

            var createRoomTypePage = new CreateRoomTypePage();
            Router.Sendkeys(createRoomTypePage.RoomTypeCodeInput, roomTypeCode);
            Router.Sendkeys(createRoomTypePage.RoomTypeNameInput, "test room type");
            //Router.TimePicker(createRoomTypePage.SetupTimeInput, DateTime.Parse("12:00 PM"));
            //Router.TimePicker(createRoomTypePage.BreakdownTimeInput, DateTime.Parse("10:00 AM"));
            Router.DropDownSelect(createRoomTypePage.BuildingDropDown, "EAST");
            Router.Click(createRoomTypePage.CreateButton);
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Click(createRoomTypePage.PopUpOkButton);
            Router.Sendkeys(setUpPage.SearchByInput, roomTypeCode);
            Assert.AreEqual(roomTypeCode, setUpPage.ValidateRoomSetupDetail("code").Text);

        }

        public void EditRoomType(string roomTypeCode)
        {
            var setUpPage = new SetUpPage();
            Router.Sendkeys(setUpPage.SearchByInput, roomTypeCode);
            Router.Click(setUpPage.EditIcon);

            var createRoomTypePage = new CreateRoomTypePage();
            Router.Sendkeys(createRoomTypePage.RoomTypeNameInput, "test edit roomType");
            Router.Click(createRoomTypePage.UpdateButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Sendkeys(setUpPage.SearchByInput, roomTypeCode);
            Assert.AreEqual("test edit roomType", setUpPage.ValidateRoomSetupDetail("name").Text);

        }

        public void DeleteRoomType(string roomTypeCode)
        {
            var setUpPage = new SetUpPage();
            Router.Sendkeys(setUpPage.SearchByInput, roomTypeCode);

            Router.Click(setUpPage.DeleteIcon);
            Router.Click(setUpPage.PopUpYesButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Sendkeys(setUpPage.SearchByInput, roomTypeCode);
            Assert.IsTrue(setUpPage.NoDataFoundLabel.Displayed);

        }

        public void CreateRoomTypeGroup(string roomTypeGroupCode)
        {
            var homePage = new HomePage();
            Router.Click(homePage.DotsButton);
            Router.Click(homePage.SettingsTab);
            var setUpPage = new SetUpPage();
            Router.Click(setUpPage.AsidePanelOptions("Room Type Grouping"));
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Click(setUpPage.CreateRoomTypeGroupButton);

            var createRoomTypeGroupPage = new CreateRoomTypeGroupPage();
            Router.Sendkeys(createRoomTypeGroupPage.RoomTypeGroupCodeInput, roomTypeGroupCode);
            Router.Sendkeys(createRoomTypeGroupPage.RoomTypeGroupNameInput, "test room group");
            Router.Click(createRoomTypeGroupPage.RoomTypesCheckBox("Select All"));
            Router.Click(createRoomTypeGroupPage.CreateButton);
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Sendkeys(setUpPage.SearchByInput, roomTypeGroupCode);
            Assert.AreEqual(roomTypeGroupCode, setUpPage.ValidateRoomSetupDetail("code").Text);

        }

        public void EditRoomTypeGroup(string roomTypeGroupCode)
        {
            var setUpPage = new SetUpPage();
            Router.Sendkeys(setUpPage.SearchByInput, roomTypeGroupCode);
            Router.Click(setUpPage.EditIcon);

            var createRoomTypeGroupPage = new CreateRoomTypeGroupPage();
            Router.Sendkeys(createRoomTypeGroupPage.RoomTypeGroupNameInput, "test edit roomGroup");
            Router.Click(createRoomTypeGroupPage.UpdateButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Sendkeys(setUpPage.SearchByInput, roomTypeGroupCode);
            Assert.AreEqual("test edit roomGroup", setUpPage.ValidateRoomSetupDetail("name").Text);

        }

        public void DeleteRoomTypeGroup(string roomTypeGroupCode)
        {
            var setUpPage = new SetUpPage();
            Router.Sendkeys(setUpPage.SearchByInput, roomTypeGroupCode);

            Router.Click(setUpPage.DeleteIcon);
            Router.Click(setUpPage.PopUpYesButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            Router.Sendkeys(setUpPage.SearchByInput, roomTypeGroupCode);
            Assert.IsTrue(setUpPage.NoDataFoundLabel.Displayed);

        }


    }
}
