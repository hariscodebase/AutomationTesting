﻿using AgilysysTests;
using NUnit.Framework;
using PMS.Pages.Home;
using PMS.Pages.Housekeeping;
using System;
using System.Threading;

namespace PMS.Scripts
{
    public class HousekeepingScripts : BaseScripts
    {

        public void CreateLostFoundItem(string item, string status)
        {
            HomePage homePage = new HomePage();
            Router.Click(homePage.HousekeepingTab);

            LostAndFoundPage lostAndFoundPage = new LostAndFoundPage();
            Router.Click(lostAndFoundPage.LostAndFoundTab);
            Router.Click(lostAndFoundPage.NewLostAndFoundButton);

            AddLostAndFoundPage addLostAndFoundPage = new AddLostAndFoundPage();
            Router.Sendkeys(addLostAndFoundPage.DescriptionInput, item);
            Router.DropDownSelect(addLostAndFoundPage.StatusDropDown, status);
            AngularUtils.WaitUntilClickable(addLostAndFoundPage.CreateButton);
            Router.ClickByActions(addLostAndFoundPage.CreateButton);
            Thread.Sleep(TimeSpan.FromSeconds(6));

            
            Router.Sendkeys(lostAndFoundPage.SearchCriteriaInput, item);
            Assert.AreEqual(item, lostAndFoundPage.ValidateLostAndFoundItem("description").Text);
            lostAndFoundPage.SearchCriteriaInput.Clear();

        }


        public void EditLostFoundItem(string item)
        {
            HomePage homePage = new HomePage();
            Router.Click(homePage.HousekeepingTab);

            LostAndFoundPage lostAndFoundPage = new LostAndFoundPage();
            Router.Click(lostAndFoundPage.LostAndFoundTab);
            Router.Sendkeys(lostAndFoundPage.SearchCriteriaInput, item);
            Router.Click(lostAndFoundPage.EditIcon);

            AddLostAndFoundPage addLostAndFoundPage = new AddLostAndFoundPage();
            Router.DropDownSelect(addLostAndFoundPage.StatusDropDown, "Found");
            Router.Sendkeys(addLostAndFoundPage.FoundByInput, "Tester");
            Router.Click(addLostAndFoundPage.UpdateButton);

        }

        public void DeleteLostFoundItem(string item)
        {
            HomePage homePage = new HomePage();
            Router.Click(homePage.HousekeepingTab);

            LostAndFoundPage lostAndFoundPage = new LostAndFoundPage();
            Router.Click(lostAndFoundPage.LostAndFoundTab);
            Router.Sendkeys(lostAndFoundPage.SearchCriteriaInput, item);
            Router.Click(lostAndFoundPage.DeleteIcon);
            Router.Click(lostAndFoundPage.PopUpYesButton);

            Assert.IsTrue(lostAndFoundPage.NoDataFoundLabel.Displayed);

        }


        public void AssignHousekeepersToRoom()
        {
            HomePage homePage = new HomePage();
            Router.Click(homePage.HousekeepingTab);

            HousekeepersAssignmentPage housekeepersAssignmentPage = new HousekeepersAssignmentPage();
            Router.Click(housekeepersAssignmentPage.HousekeepersAssignmentTab);
            Router.Click(housekeepersAssignmentPage.AvailableHousekeepersSelectCheckBox);
            Router.Click(housekeepersAssignmentPage.AllocateSelectedItemsButton);
            Router.Click(housekeepersAssignmentPage.SaveButton);
            Router.Click(housekeepersAssignmentPage.PopUpOkButton);
            Router.Click(housekeepersAssignmentPage.NextButton);

            Router.Click(housekeepersAssignmentPage.UnassignedRoomsSelectCheckBox);
            Router.Click(housekeepersAssignmentPage.AssignButton);
            Router.Click(housekeepersAssignmentPage.ChooseHousekeepersRadioButton);
            Router.Click(housekeepersAssignmentPage.HousekeeperAssignButton);
            Router.Click(housekeepersAssignmentPage.FinishButton);

            Router.Click(housekeepersAssignmentPage.DotsHorizontalButton);
            Router.Click(housekeepersAssignmentPage.ClearAllAssignmentButton);
            Router.Click(housekeepersAssignmentPage.FinishButton);
            Router.Click(housekeepersAssignmentPage.PreviousButton);
            Router.Click(housekeepersAssignmentPage.DeAllocateAllButton);
            Router.Click(housekeepersAssignmentPage.SaveButton);
            Assert.IsTrue(housekeepersAssignmentPage.PopUpConfirmationIcon.Displayed);
        }





    }
}
