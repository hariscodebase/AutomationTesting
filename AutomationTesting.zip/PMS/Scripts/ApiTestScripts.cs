﻿using AgilysysTests;
using AgilysysTests.Configurations;
using AventStack.ExtentReports;
using Newtonsoft.Json.Linq;
using NUnit.Framework;
using RestSharp;
using System;
using System.Globalization;
using System.IO;
using System.Net;

namespace PMS.Scripts
{
    class ApiTestScripts : BaseScripts
    {
        public string GetLoginDetails()
        {
            RestClient client = new RestClient(Settings.TenantURL);
            RestRequest request = new RestRequest("api/Property/GetLoginDetails", Method.POST);
            var loginJson = JObject.Parse(File.ReadAllText(Directory.GetCurrentDirectory() + $@"\ScenarioData\{Settings.Environment}\Login.json"));
            request.AddParameter("application/json", loginJson, ParameterType.RequestBody);

            IRestResponse response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            var bearerToken = JObject.Parse(response.Content).SelectToken("result.token").Value<string>();
            DateTime propertyDate = JObject.Parse(response.Content).SelectToken("result.userProperties.[0].propertyDate").Value<DateTime>();
            Settings.PropertyDate = propertyDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
            return bearerToken;
        }

        public string GetSessionDetails(string bearerToken)
        {
            RestClient client = new RestClient(Settings.TenantURL);
            RestRequest request = new RestRequest("api/User/session", Method.POST);
            var sessionJson = JObject.Parse(File.ReadAllText(Directory.GetCurrentDirectory() + $@"\ScenarioData\{Settings.Environment}\Session.json"));
            sessionJson.SelectToken("startTime").Replace(DateTime.Now.ToString("yyyy-MM-ddT00:00:00"));
            sessionJson.SelectToken("userToken").Replace(bearerToken);

            request.AddParameter("application/json", sessionJson, ParameterType.RequestBody);
            request.AddHeader("Authorization", $"Bearer {bearerToken}");

            IRestResponse response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.OK, response.StatusCode);
            var sessionId = JObject.Parse(response.Content).SelectToken("result").Value<string>();
            return sessionId;
        }

        public string CreateReservationViaApi()
        {
            var bearerToken = GetLoginDetails();
            var sessionId = GetSessionDetails(bearerToken);
            RestClient client = new RestClient(Settings.PmsGatewayURL);
            RestRequest request = new RestRequest("PMSGateway/ReservationService/Reservation/true/false/false", Method.POST);
            string createReservationJsonPath = Directory.GetCurrentDirectory() + $@"\ScenarioData\{Settings.Environment}\CreateReservation.json";
            var createReservationJson = JObject.Parse(File.ReadAllText(createReservationJsonPath));
            createReservationJson.SelectToken("stay.arrivalDate").Replace(Convert.ToDateTime(Settings.PropertyDate).ToString("yyyy-MM-ddT00:00:00"));
            createReservationJson.SelectToken("stay.departureDate").Replace(Convert.ToDateTime(Settings.PropertyDate).AddDays(1).ToString("yyyy-MM-ddT00:00:00"));
            
            createReservationJson.SelectToken("stay.stayRequestInfo.confirmationRequestedOn").Replace(Convert.ToDateTime(Settings.PropertyDate).ToString("yyyy-MM-dd"));
            createReservationJson.SelectToken("stay.stayMarketingInfos[0].stayDate").Replace(Convert.ToDateTime(Settings.PropertyDate).ToString("yyyy-MM-dd"));
            createReservationJson.SelectToken("stay.stayDetailInfos[0].stayDate").Replace(Convert.ToDateTime(Settings.PropertyDate).ToString("yyyy-MM-dd"));
            createReservationJson.SelectToken("stayRoomInfos[0][0].stayDate").Replace(Convert.ToDateTime(Settings.PropertyDate).ToString("yyyy-MM-ddT00:00:00"));


            request.AddHeader("Authorization", $"Bearer {bearerToken}");
            request.AddHeader("SessionId", sessionId);
            request.AddParameter("application/json", createReservationJson, ParameterType.RequestBody);

            IRestResponse response = client.Execute(request);

            Assert.AreEqual(HttpStatusCode.Created, response.StatusCode, "Create Reservation via Api failed");
            var confNumber = JObject.Parse(response.Content).SelectToken("result.confirmationNumbers[0]").Value<string>();

            Logger.Write($"Reservation Number: {confNumber}");
            BaseNunitInitialize._test.Log(String.IsNullOrEmpty(confNumber) ? Status.Fail : Status.Pass, $"Reservation Number: {confNumber}");

            return confNumber;
        }

    }
}
