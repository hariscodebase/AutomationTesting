﻿using AgilysysTests;
using AgilysysTests.Utilities;
using NUnit.Framework;
using OpenQA.Selenium;
using PMS.Pages.Guest;
using System;
using System.Threading;

namespace PMS.Scripts
{
    public class GuestScripts : BaseScripts
    {

        public void CreateNewGuest()
        {            
            var allGuestPage = new AllGuestPage();
            Router.Click(allGuestPage.GuestTab);
            Router.Click(allGuestPage.AllGuestTab);
            Router.Click(allGuestPage.CreateGuestButton);

            var generalInformationPage = new GeneralInformationPage();
            string firstName = TestUtils.RandomAlpha(6);
            dictionary.Add("FirstName", firstName);
            Router.Sendkeys(generalInformationPage.FirstNameInput, firstName);
            Router.Sendkeys(generalInformationPage.LastNameInput, "autotest");            
            Router.Sendkeys(generalInformationPage.InitialInput, "E");
            Router.DropDownSelect(generalInformationPage.TitleDropDown, "Mr.", true);
            //Router.SearchAndSelect(generalInformationPage.AddressInput(), "214 North Palm Avenue", 0);
            
            Router.Sendkeys(generalInformationPage.AddressInput(), "214 North Palm Avenue");
            Router.Sendkeys(generalInformationPage.AddressInput(), Keys.Tab);
            Router.Sendkeys(generalInformationPage.PostalCodeInput, "92376");
            Router.Sendkeys(generalInformationPage.CityInput, "Rialto");
            Router.Sendkeys(generalInformationPage.StateInput, "California");
            Router.Sendkeys(generalInformationPage.CountryInput, "United States");


            Router.DropDownSelect(generalInformationPage.PhoneDropDown(), "Mobile", true);
            Router.Sendkeys(generalInformationPage.CountryCodeInput, "1");
            Router.Sendkeys(generalInformationPage.PhoneNumberInput, TestUtils.RandomNumeric(12));
            Router.DropDownSelect(generalInformationPage.EmailDropDown(), "Personal", true);
            Router.Sendkeys(generalInformationPage.EmailIdInput, "bruno2020@agilysys.com");
            Router.DropDownSelect(generalInformationPage.GuestTypeDropDown, "PMS");
            Router.Click(generalInformationPage.SaveAndCloseButton);

        }

        public void CheckAddedGuest()
        {
            var allGuestPage = new AllGuestPage();
            Router.Sendkeys(allGuestPage.SearchByInput, dictionary["FirstName"]);
            Assert.AreEqual(dictionary["FirstName"], allGuestPage.GuestListDetail(0, "firstName").Text.Trim());
            Assert.AreEqual("Mr.", allGuestPage.GuestListDetail(0, "title").Text.Trim());
            Assert.AreEqual("214 North Palm Avenue", allGuestPage.GuestListDetail(0, "address").Text.Trim());
            StringAssert.Contains("bruno", allGuestPage.GuestListDetail(0, "emailId").Text.Trim());
            Assert.AreEqual("Rialto", allGuestPage.GuestListDetail(0, "city").Text.Trim());
            Assert.AreEqual("California", allGuestPage.GuestListDetail(0, "state").Text.Trim());
            Assert.AreEqual("92376", allGuestPage.GuestListDetail(0, "postalCode").Text.Trim());
        }

        public void EditGuest()
        {
            var allGuestPage = new AllGuestPage();
            Router.Click(allGuestPage.GuestTab);
            Router.Click(allGuestPage.AllGuestTab);
            Router.Sendkeys(allGuestPage.SearchByInput, dictionary["FirstName"]);
            Router.Click(allGuestPage.GuestEditButton);
            Thread.Sleep(TimeSpan.FromSeconds(10));
            var generalInformationPage = new GeneralInformationPage();
            string updatedName = TestUtils.RandomAlpha(7);
            dictionary.Add("UpdatedName", updatedName);
            //Router.Click(generalInformationPage.PopUpOkButton);
            Router.Sendkeys(generalInformationPage.FirstNameInput, dictionary["UpdatedName"]);
            Router.Click(generalInformationPage.UpdateButton);

        }

        public void CheckUpdatedGuest()
        {
            var allGuestPage = new AllGuestPage();
            Router.Sendkeys(allGuestPage.SearchByInput, dictionary["UpdatedName"]);
            Assert.AreEqual(dictionary["UpdatedName"], allGuestPage.GuestListDetail(0, "firstName").Text.Trim());
            Assert.AreEqual("E", allGuestPage.GuestListDetail(0, "initial").Text.Trim());
            Assert.AreEqual("Mr.", allGuestPage.GuestListDetail(0, "title").Text.Trim());
            Assert.AreEqual("214 North Palm Avenue", allGuestPage.GuestListDetail(0, "address").Text.Trim());
            StringAssert.Contains("bruno", allGuestPage.GuestListDetail(0, "emailId").Text.Trim());
            Assert.AreEqual("Rialto", allGuestPage.GuestListDetail(0, "city").Text.Trim());
            Assert.AreEqual("California", allGuestPage.GuestListDetail(0, "state").Text.Trim());
            Assert.AreEqual("92376", allGuestPage.GuestListDetail(0, "postalCode").Text.Trim());
        }

    }
}
