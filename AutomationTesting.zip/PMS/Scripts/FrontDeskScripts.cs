﻿using AgilysysTests;
using NUnit.Framework;
using PMS.Pages.Accounting;
using PMS.Pages.FrontDesk;
using PMS.Pages.Home;
using PMS.Pages.Reservation;
using System;
using System.Threading;

namespace PMS.Scripts
{
    public class FrontDeskScripts : BaseScripts
    {

        public void NavigateToFrontDesk()
        {
            HomePage homePage = new HomePage();
            Router.Click(homePage.FrontDeskTab);            

        }

        public void WalkIn()
        {
            WalkInPage walkInPage = new WalkInPage();
            Router.Click(walkInPage.WalkInTab);

            ReservationsListPage reservationDetailsPage = new ReservationsListPage();
            Assert.IsTrue(reservationDetailsPage.CreateReservationButton.Displayed);
        }


        public void CheckIn()
        {
            FrontDeskHomePage frontDeskHomePage = new FrontDeskHomePage();
            Router.Click(frontDeskHomePage.CheckInTab);
            AngularUtils.WaitUntilClickable(frontDeskHomePage.GuestRecheckInRadioButton);
            Router.DropDownSelect(frontDeskHomePage.SetupOptionsDropDown, "Check In");

            ReservationsListPage reservationDetailsPage = new ReservationsListPage();
            Assert.IsTrue(reservationDetailsPage.CreateReservationButton.Displayed);
        }


        public void PostActions(string confNum)
        {
            FrontDeskHomePage frontDeskHomePage = new FrontDeskHomePage();
            Router.Click(frontDeskHomePage.PostActionsTab);

            Router.DropDownSelect(frontDeskHomePage.SetupOptionsDropDown, "Post Charges");
            Router.Sendkeys(frontDeskHomePage.SearchByInput, confNum);
            Router.Click(frontDeskHomePage.ReservationListDetail("confirmationId"));

        }


        public void CheckOut()
        {
            FrontDeskHomePage frontDeskHomePage = new FrontDeskHomePage();
            Router.Click(frontDeskHomePage.CheckOutTab);
            Router.Click(frontDeskHomePage.InHouseRadioButton);
            Router.Click(frontDeskHomePage.ReservationListDetail("action"));

            CheckOutPage checkOutPage = new CheckOutPage();
            Assert.IsTrue(checkOutPage.CheckOutButton.Displayed);
            
        }


        public void SetRoomConditions()
        {
            FrontDeskHomePage frontDeskHomePage = new FrontDeskHomePage();
            Router.Click(frontDeskHomePage.RoomSectionsTab);
            Router.Click(frontDeskHomePage.RoomConditionsListDetail("roomNumber"));
            string condition = frontDeskHomePage.RoomConditionsListDetail("condition").Text.Contains("Clean") ? "Dirty" : "Clean"; 
            Router.Click(frontDeskHomePage.SetRoomConditionsRadioButton(condition));
            Router.Click(frontDeskHomePage.ProcessButton);
            Thread.Sleep(TimeSpan.FromSeconds(3));
            StringAssert.Contains(condition, frontDeskHomePage.RoomConditionsListDetail("condition").Text);

        }


        public void ProcessRoomRack()
        {
            FrontDeskHomePage frontDeskHomePage = new FrontDeskHomePage();
            Router.Click(frontDeskHomePage.RoomRackTab);
            Router.Click(frontDeskHomePage.ReservationTypeCheckBox("Nightly"));
            Router.Click(frontDeskHomePage.ProcessButton);
            Assert.IsTrue(frontDeskHomePage.RoomRackContent.Displayed);
            StringAssert.Contains("ROOM RACK", frontDeskHomePage.RoomRackTitle.Text);
            Router.Click(frontDeskHomePage.RoomCell(1));
            Router.Click(frontDeskHomePage.LinkText("RESERVE THIS ROOM"));

            ReservationDetailsPage reservationDetailsPage = new ReservationDetailsPage();
            Assert.IsTrue(reservationDetailsPage.ReservationTypeRadioGroup.Displayed);


        }


    }
}
