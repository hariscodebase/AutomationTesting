﻿using AgilysysTests;
using AgilysysTests.Configurations;
using NUnit.Framework;
using PMS.Pages.Reservation;
using System;
using System.Threading;

namespace PMS.Scripts
{
    public class FolioScripts : BaseScripts
    {

        public void CreateFolio(string reservationNumber)
        {
            SearchAndViewReservation(reservationNumber);
            
            var viewReservationPage = new ViewReservationPage();
            Router.Click(viewReservationPage.ReservationActionsList("Folio"));
            Thread.Sleep(TimeSpan.FromSeconds(5));

            var folioPage = new FolioPage();
            Router.Click(folioPage.SplitDefinitionTabButton);
            AngularUtils.WaitUntilClickable(folioPage.CreditLimitLabel);
            Router.Click(folioPage.AddFolioButton);
            Router.Click(folioPage.TickIconButton);
            Router.Click(folioPage.SaveButton);
            Assert.IsTrue(folioPage.PopUpConfirmationIcon.Displayed);
            Router.Click(folioPage.PopUpOkButton);
        }

        public void SetPaymentMethod(string reservationNumber)
        {
            SearchAndViewReservation(reservationNumber);

            var viewReservationPage = new ViewReservationPage();
            Router.Click(viewReservationPage.ReservationActionsList("Folio"));
            Thread.Sleep(TimeSpan.FromSeconds(5));

            var folioPage = new FolioPage();
            Router.Click(folioPage.SplitDefinitionTabButton);
            Router.Click(folioPage.SetPaymentIconButton("Folio 1 - Authorize"));
            Router.Sendkeys(folioPage.AuthorizationAmountInput, "500.00");
            Router.Click(folioPage.ProcessButton);
            Assert.AreEqual("Authorization Successful.", folioPage.PopUpMessage.Text);
            Router.Click(folioPage.PopUpInfoOkButton);
            Router.Click(folioPage.SavePaymentMethod);
            StringAssert.Contains("500.00", folioPage.CreditLimitLabel.Text);
            Router.Click(folioPage.SaveButton);
            Assert.IsTrue(folioPage.PopUpConfirmationIcon.Displayed);
            Router.Click(folioPage.PopUpOkButton);

        }

        public void FolioPosting()
        {
            var folioPage = new FolioPage();
            Router.Click(folioPage.TransactionItemsButton);
            string itemName = Settings.Environment.Equals("QAINT") ? "Juice lemon" : "Room";
            Router.Click(folioPage.AddItemButton(itemName));
            if (Settings.Environment.Equals("DEV")) Router.DropDownSelect(folioPage.BuildingDropDown, 1);
            Router.Click(folioPage.PostButton);            
            Thread.Sleep(TimeSpan.FromSeconds(4));
            AngularUtils.WaitUntilClickable(folioPage.PopUpMessage);
            Assert.AreEqual("Posting Success", folioPage.PopUpMessage.Text);
            Router.Click(folioPage.PopUpOkButton);
        }


        public void MakePayment()
        {           

            var folioPage = new FolioPage();
            Router.Click(folioPage.MakePaymentButton);
            Router.Click(folioPage.ChooseFolioCheckBox("Folio 1"));
            Router.Click(folioPage.PayButton);
            Router.Click(folioPage.ProceedWithCardPopUpYesButton);
            Assert.IsTrue(folioPage.PopUpConfirmationIcon.Displayed);

        }


        public void VerifyFolioStatement(string reservationNumber)
        {
            var folioPage = new FolioPage();
            Router.Click(folioPage.PopUpOkButton);
            Router.Click(folioPage.StatementTabButton);            
            StringAssert.Contains("Room", folioPage.StatementTableBody.Text);

        }



    }
}
