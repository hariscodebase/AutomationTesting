﻿using AgilysysTests;
using NUnit.Framework;
using PMS.Pages.Home;
using System;
using System.Threading;

namespace PMS.Scripts
{
    public class DashboardScripts : BaseScripts
    {

        public void DashboardView()
        {
            var homePage = new HomePage();
            Router.Click(homePage.HomeTab);
            //Assert.AreEqual("Dashboard", homePage.DashboardTitleLabel.Text);
            Thread.Sleep(TimeSpan.FromSeconds(10));
            Assert.IsTrue(homePage.ActivityChart.Displayed);            
            StringAssert.Contains("Activity", homePage.ActivityChart.Text);
            Assert.IsTrue(homePage.AverageDailyRateChart.Displayed);
            StringAssert.Contains("Average Daily Rate", homePage.AverageDailyRateChart.Text);
            Assert.IsTrue(homePage.BestAvailableRateChart.Displayed);
            StringAssert.Contains("Best Available Rate", homePage.BestAvailableRateChart.Text);
            Assert.IsTrue(homePage.TotalArrivalChart.Displayed);
            StringAssert.Contains("Total Arrivals", homePage.TotalArrivalChart.Text);
            Assert.IsTrue(homePage.TotalDepartureChart.Displayed);
            StringAssert.Contains("Total Departures", homePage.TotalDepartureChart.Text);
            Assert.IsTrue(homePage.VIPChart.Displayed);
            StringAssert.Contains("VIP's", homePage.VIPChart.Text);
            Assert.IsTrue(homePage.OthersChart.Displayed);
            StringAssert.Contains("Others", homePage.OthersChart.Text);
            Assert.IsTrue(homePage.TotalGuestChart.Displayed);
            StringAssert.Contains("Total Guests", homePage.TotalGuestChart.Text);
            Assert.IsTrue(homePage.RecentBookingsChart.Displayed);
            Assert.IsTrue(homePage.TotalRevenueWidget.Displayed);
            Assert.IsTrue(homePage.HousekeepingChart.Displayed);
            StringAssert.Contains("Housekeeping Status", homePage.HousekeepingChart.Text);
            Assert.IsTrue(homePage.ComplementaryRoomsChart.Displayed);
            StringAssert.Contains("Complimentary Rooms", homePage.ComplementaryRoomsChart.Text);
            Assert.IsTrue(homePage.ROHStayChart.Displayed);
            StringAssert.Contains("ROH Stay", homePage.ROHStayChart.Text);
            Assert.IsTrue(homePage.ScheduleRoomMoveChart.Displayed);
            StringAssert.Contains("Schedule Room Move", homePage.ScheduleRoomMoveChart.Text);

        }



    }
}
