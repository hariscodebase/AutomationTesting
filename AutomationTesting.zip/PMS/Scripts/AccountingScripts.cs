﻿using AgilysysTests;
using NUnit.Framework;
using PMS.Pages.Accounting;
using PMS.Pages.Home;

namespace PMS.Scripts
{
    public class AccountingScripts : BaseScripts
    {

        public void NavigateToAccounting()
        {
            HomePage homePage = new HomePage();
            Router.Click(homePage.AccountingTab);            

        }

        public void CreateARAccountCategory(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Click(accountsReceivablePage.AsidePanelOptions("A/R Account Categories"));
            Router.Click(accountsReceivablePage.CreateAccountCategoryButton);

            CreateAccountCategoryPage createAccountCategoryPage = new CreateAccountCategoryPage();
            Router.Sendkeys(createAccountCategoryPage.CategoryCodeInput, name);
            Router.Sendkeys(createAccountCategoryPage.CategoryDescriptionInput, name);
            Router.Click(createAccountCategoryPage.SaveButton);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.AreEqual(name, accountsReceivablePage.ValidateRoomSetupDetail("code").Text);
            Router.Click(accountsReceivablePage.CancelIcon);

        }

        public void EditARAccountCategory(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Router.Click(accountsReceivablePage.EditIcon);

            CreateAccountCategoryPage createAccountCategoryPage = new CreateAccountCategoryPage();
            Router.Sendkeys(createAccountCategoryPage.CategoryDescriptionInput, "TEST1");
            Router.Click(createAccountCategoryPage.UpdateButton);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.AreEqual(name, accountsReceivablePage.ValidateRoomSetupDetail("code").Text);
            Router.Click(accountsReceivablePage.CancelIcon);

        }

        public void DeleteARAccountCategory(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Router.Click(accountsReceivablePage.DeleteIcon);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.IsTrue(accountsReceivablePage.NoDataFoundLabel.Displayed);

        }

        public void CreateARAccountCategory2(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Click(accountsReceivablePage.AsidePanelOptions("A/R Account Categories 2"));
            Router.Click(accountsReceivablePage.CreateAccountCategory2Button);

            CreateAccountCategory2Page createAccountCategory2Page = new CreateAccountCategory2Page();
            Router.Sendkeys(createAccountCategory2Page.Category2CodeInput, name);
            Router.Sendkeys(createAccountCategory2Page.Category2DescriptionInput, name);
            Router.Click(createAccountCategory2Page.SaveButton);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.AreEqual(name, accountsReceivablePage.ValidateRoomSetupDetail("code").Text);
            Router.Click(accountsReceivablePage.CancelIcon);


        }

        public void EditARAccountCategory2(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Router.Click(accountsReceivablePage.EditIcon);

            CreateAccountCategory2Page createAccountCategory2Page = new CreateAccountCategory2Page();
            Router.Sendkeys(createAccountCategory2Page.Category2DescriptionInput, "TEST1");
            Router.Click(createAccountCategory2Page.UpdateButton);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.AreEqual(name, accountsReceivablePage.ValidateRoomSetupDetail("code").Text);
            Router.Click(accountsReceivablePage.CancelIcon);

        }

        public void DeleteARAccountCategory2(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Router.Click(accountsReceivablePage.DeleteIcon);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.IsTrue(accountsReceivablePage.NoDataFoundLabel.Displayed);

        }

        public void CreateARMiscellaneousCategory(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Click(accountsReceivablePage.AsidePanelOptions("A/R Miscellaneous Types"));
            Router.Click(accountsReceivablePage.CreateARMiscellaneousCategory);

            CreateARMiscellaneousCategoryPage createARMiscellaneousCategoryPage = new CreateARMiscellaneousCategoryPage();
            Router.Sendkeys(createARMiscellaneousCategoryPage.MiscellaneousCategoryCodeInput, name);
            Router.Sendkeys(createARMiscellaneousCategoryPage.MiscellaneousCategoryDescriptionInput, name);
            Router.Click(createARMiscellaneousCategoryPage.CreateButton);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.AreEqual(name, accountsReceivablePage.ValidateRoomSetupDetail("code").Text);
            Router.Click(accountsReceivablePage.CancelIcon);


        }

        public void EditARMiscellaneousCategory(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Router.Click(accountsReceivablePage.EditIcon);

            CreateARMiscellaneousCategoryPage createARMiscellaneousCategoryPage = new CreateARMiscellaneousCategoryPage();
            Router.Sendkeys(createARMiscellaneousCategoryPage.MiscellaneousCategoryDescriptionInput, "TEST1");
            Router.Click(createARMiscellaneousCategoryPage.UpdateButton);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.AreEqual(name, accountsReceivablePage.ValidateRoomSetupDetail("code").Text);
            Router.Click(accountsReceivablePage.CancelIcon);

        }

        public void DeleteARMiscellaneousCategory(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Router.Click(accountsReceivablePage.DeleteIcon);
            Router.Click(accountsReceivablePage.PopUpYesButton);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.IsTrue(accountsReceivablePage.NoDataFoundLabel.Displayed);

        }


        public void CreateARDiscountCategory(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Click(accountsReceivablePage.AsidePanelOptions("A/R Discount Categories"));
            Router.Click(accountsReceivablePage.CreateARDiscountCategory);

            CreateARDiscountCategoryPage createARDiscountCategoryPage = new CreateARDiscountCategoryPage();
            Router.Sendkeys(createARDiscountCategoryPage.DiscountCategoryCodeInput, name);
            Router.Sendkeys(createARDiscountCategoryPage.DiscountCategoryDescriptionInput, name);
            Router.Click(createARDiscountCategoryPage.CreateButton);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.AreEqual(name, accountsReceivablePage.ValidateRoomSetupDetail("code").Text);
            Router.Click(accountsReceivablePage.CancelIcon);

        }

        public void EditARDiscountCategory(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Router.Click(accountsReceivablePage.EditIcon);

            CreateARDiscountCategoryPage createARDiscountCategoryPage = new CreateARDiscountCategoryPage();
            Router.Sendkeys(createARDiscountCategoryPage.DiscountCategoryDescriptionInput, "TEST1");
            Router.Click(createARDiscountCategoryPage.UpdateButton);

            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.AreEqual(name, accountsReceivablePage.ValidateRoomSetupDetail("code").Text);
            Router.Click(accountsReceivablePage.CancelIcon);

        }

        public void DeleteARDiscountCategory(string name)
        {
            AccountsReceivablePage accountsReceivablePage = new AccountsReceivablePage();
            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Router.Click(accountsReceivablePage.DeleteIcon);
            Router.Click(accountsReceivablePage.PopUpYesButton);


            Router.Sendkeys(accountsReceivablePage.SearchByInput, name);
            Assert.IsTrue(accountsReceivablePage.NoDataFoundLabel.Displayed);

        }



    }
}
