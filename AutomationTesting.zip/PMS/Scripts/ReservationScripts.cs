﻿using AgilysysTests;
using AgilysysTests.Configurations;
using AventStack.ExtentReports;
using NUnit.Framework;
using PMS.Pages.Reservation;
using System;
using System.Threading;

namespace PMS.Scripts
{
    public class ReservationScripts : BaseScripts
    {

        public void ValidateReservation(string reservationNumber)
        {
            var reservationsListPage = new ReservationsListPage();
            Router.Click(reservationsListPage.ReservationsTab);
            Router.Sendkeys(reservationsListPage.SearchBoxInput, reservationNumber);
            Assert.AreEqual(reservationNumber, reservationsListPage.ReservationListDetail("confirmationNumber").Text);
        }

        public string CreateReservation(string guestName = "Hari Dinesh")
        {

            var reservationsListPage = new ReservationsListPage();
            Router.Click(reservationsListPage.CreateReservationButton);

            //Reservation Details
            var reservationDetailsPage = new ReservationDetailsPage();
            Router.DropDownSelect(reservationDetailsPage.ReservationStatusDropDown, "RESERVATION");
            AngularUtils.WaitUntilClickable(reservationDetailsPage.NoOfGuestsLabel);
            Router.RadioButtonSelect(reservationDetailsPage.ReservationTypeRadioGroup, "Nightly");
            //Router.DatePicker(reservationDetailsPage.ArrivalDateInput, DateTime.Parse(DateTime.Now.AddDays(4).ToString()));
            //Router.DatePicker(reservationDetailsPage.DepartureDateInput, DateTime.Parse(DateTime.Now.AddDays(5).ToString()));
            Router.Sendkeys(reservationDetailsPage.RoomsInput, "1");
            Router.SearchAndSelect(reservationDetailsPage.SearchByInput, guestName, guestName);
            Router.Click(reservationDetailsPage.IncludeNonBeddedCheckBox);
            Router.Click(reservationDetailsPage.IncludeUnavailableRatesCheckBox);
            Router.Click(reservationDetailsPage.CheckAvailablilityButton);

            // Availability
            var availabiltyPage = new AvailabiltyPage();
            Router.Click(reservationDetailsPage.AvailabilityTab);
            Router.Click(availabiltyPage.ExpandAllCollapseAllButton);

            Router.TablePicker("KNS", "BAR", 0);

            Router.Click(availabiltyPage.StayInformationTab);

            // Stay Information
            var stayInformationPage = new StayInformationPage();
            Router.Select(stayInformationPage.GuestTypeHeaderSelect, 1);
            Router.Select(stayInformationPage.OriginCodeHeaderSelect, 1);
            Router.Click(stayInformationPage.PopUpOkButton);
            Router.Select(stayInformationPage.Segment1HeaderSelect, 1);
            Router.Select(stayInformationPage.Segment2HeaderSelect, 1);


            Router.Click(stayInformationPage.PaymentInformationTab);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            //Payment Information
            var paymentInformationPage = new PaymentInformationPage();
            //Router.Sendkeys(paymentInformationPage.ExemptEntityInput, "Automtaion Test");
            Router.DropDownSelect(paymentInformationPage.PaymentMethodDropDown, "Authorize");
            //Router.Click(paymentInformationPage.PopUpNoButton); <Commenting this as pop up is not displaying now>
            
            Router.Click(paymentInformationPage.BookButton);
            //Router.Click(paymentInformationPage.PopUpContinueButton); <Passcode popup not displaying now>
            
            string confirmationNumber = paymentInformationPage.ConfirmationNumberLabel.Text;
            Router.Click(paymentInformationPage.SaveAndCloseButton);
            

            Logger.Write($"Confirmation Number: {confirmationNumber}");
            _test.Log(Status.Pass, $"Confirmation Number: {confirmationNumber}");
            return confirmationNumber;
        }

        public void EditReservation(string confirmationNumber)
        {
            SearchAndViewReservation(confirmationNumber);

            var viewReservationPage = new ViewReservationPage();
            Router.Click(viewReservationPage.ModifyButton);

            var reservationDetailsPage = new ReservationDetailsPage();
            AngularUtils.WaitUntilClickable(reservationDetailsPage.NoOfGuestsLabel);
            Router.Click(reservationDetailsPage.PaymentInformationTab);
            Thread.Sleep(TimeSpan.FromSeconds(5));

            var paymentInformationPage = new PaymentInformationPage();
            Router.DropDownSelect(paymentInformationPage.PaymentMethodDropDown, "VISA");
            Router.Click(paymentInformationPage.PopUpNoButton);


            Router.Click(reservationDetailsPage.UpdateButton);
            Thread.Sleep(TimeSpan.FromSeconds(3));

            Assert.AreEqual("VISA", reservationDetailsPage.ConfirmationPopUpDetails("lbl_paymentMethod").Text);
            Logger.Write($"Confirmation Number: {confirmationNumber}");
            _test.Log(Status.Pass, $"Confirmation Number: {confirmationNumber}");
        }

        public void ViewReservation(string confirmationNumber)
        {
            SearchAndViewReservation(confirmationNumber);

            var viewReservationPage = new ViewReservationPage();
            Assert.IsTrue(viewReservationPage.ReservationViewDetail("Number of Nights").Displayed);
            Assert.IsTrue(viewReservationPage.ReservationViewDetail("Payment Method").Displayed);

        }

        public void CheckInReservation(string confirmationNumber)
        {
            SearchAndViewReservation(confirmationNumber);

            var viewReservationPage = new ViewReservationPage();
            
            Router.Click(viewReservationPage.ReservationActionsList("Check In"));
            if(Settings.Environment.Equals("QAINT")) Router.Click(viewReservationPage.PopUpNoButton);
            Thread.Sleep(TimeSpan.FromSeconds(5));
            
            
            var checkInPage = new CheckInPage();            
            Router.Click(checkInPage.CheckInButton);
            Router.Sendkeys(checkInPage.RequestKeyInput, "2");
            Router.Click(checkInPage.ContinueButton);
            if(Settings.Environment.Equals("DEV")) Router.Click(checkInPage.PopUpCloseButton);

            Assert.IsTrue(viewReservationPage.CheckedInHighlightedLabel.Displayed);
        }

        public void CheckOutReservation(string confirmationNumber)
        {
            var viewReservationPage = new ViewReservationPage();
            Router.Click(viewReservationPage.ReservationActionsList("Check Out"));

            var checkOutPage = new CheckOutPage();
            Router.Click(checkOutPage.PopUpYesButton);
            Router.Click(checkOutPage.PopUpOkButton);

            Router.Click(checkOutPage.CheckOutButton);
            Assert.AreEqual("Checked Out Successfully", checkOutPage.PopUpMessage.Text);
            Router.Click(checkOutPage.PopUpOkButton);

            Assert.IsTrue(viewReservationPage.CheckedOutHighlightedLabel.Displayed);

        }

        public string CopyStay(string confirmationNumber)
        {
            SearchAndViewReservation(confirmationNumber);

            var viewReservationPage = new ViewReservationPage();
            Router.Click(viewReservationPage.ReservationActionsList("Copy This Stay"));
            Thread.Sleep(TimeSpan.FromSeconds(5));

            var copyThisStayPage = new CopyThisStayPage();
            Router.Click(copyThisStayPage.CopyGuestInfoButton);
            Router.DropDownSelect(copyThisStayPage.RoomTypeDropDown, "KNS");
            Router.Click(copyThisStayPage.SetAsShareCheckBox);
            Router.Click(copyThisStayPage.CopyButton);

            string copiedPopUpMsg = copyThisStayPage.PopUpMessage.Text.Trim();
            string copiedToReservationNum = copiedPopUpMsg.Substring(copiedPopUpMsg.Length - 6);
            Logger.Write($"Reservation copied from {confirmationNumber} to {copiedToReservationNum}");
            _test.Log(Status.Pass, copiedPopUpMsg);

            Router.Click(copyThisStayPage.PopUpOkButton);
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Click(viewReservationPage.SectionBackButton);
            return copiedToReservationNum;
        }

        public void TransferStay(string confirmationNumber)
        {
            var reservationsListPage = new ReservationsListPage();
            SearchAndViewReservation(confirmationNumber);

            var viewReservationPage = new ViewReservationPage();
            Router.Click(viewReservationPage.ReservationActionsList("Transfer the Stay"));
            Thread.Sleep(TimeSpan.FromSeconds(5));

            var transferTheStayPage = new TransferTheStayPage();
            Router.Sendkeys(transferTheStayPage.SearchByInput, "Automation");
            Router.Click(transferTheStayPage.SearchButton);
            Router.Click(transferTheStayPage.SelectGuestRadioButton);
            Router.Click(transferTheStayPage.SelectAllCheckBox);
            Router.Click(transferTheStayPage.TransferButton);

            string transferedPopUpMsg = transferTheStayPage.PopUpMessage.Text.Trim();
            Assert.IsTrue(transferTheStayPage.PopUpConfirmationIcon.Displayed);
            Logger.Write(transferedPopUpMsg);
            _test.Log(Status.Pass, transferedPopUpMsg);

            Router.Click(transferTheStayPage.PopUpOkButton);
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Click(viewReservationPage.SectionBackButton);
            ValidateReservation(confirmationNumber);
            Assert.AreEqual("Automation", reservationsListPage.ReservationListDetail("firstName").Text);
        }

        public void FolioPosting(string confirmationNumber)
        {
            SearchAndViewReservation(confirmationNumber);

            var viewReservationPage = new ViewReservationPage();
            Router.Click(viewReservationPage.ReservationActionsList("Folio"));
            Thread.Sleep(TimeSpan.FromSeconds(5));

            var folioPage = new FolioPage();
            Router.Click(folioPage.TransactionItemsButton);
            string itemName = Settings.Environment.Equals("QAINT") ? "Juice lemon" : "Room";
            Router.Click(folioPage.AddItemButton(itemName));
            if(Settings.Environment.Equals("DEV")) Router.DropDownSelect(folioPage.BuildingDropDown, 0);
            Router.Click(folioPage.PostButton);
            Router.Click(folioPage.PopUpYesButton);
            Thread.Sleep(TimeSpan.FromSeconds(4));
            AngularUtils.WaitUntilClickable(folioPage.PopUpMessage);
            Assert.AreEqual("Posting Success", folioPage.PopUpMessage.Text);

        }

        public void AddAdditionalNames(string confirmationNumber)
        {
            SearchAndViewReservation(confirmationNumber);

            var viewReservationPage = new ViewReservationPage();
            Router.Click(viewReservationPage.ReservationActionsList("Additional Names"));
            Thread.Sleep(TimeSpan.FromSeconds(5));

            var additionalNamesPage = new AdditionalNamesPage();
            Router.Sendkeys(additionalNamesPage.SearchByInput, "joe biden");
            Thread.Sleep(TimeSpan.FromSeconds(3));
            Router.Click(additionalNamesPage.AddButton);
            Router.Click(additionalNamesPage.SaveButton);
        }

    }
}
