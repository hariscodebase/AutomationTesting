﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Housekeeping
{
    public class AddLostAndFoundPage : BasePage
    {
        public IWebElement LostAndFoundTab => Finder.By(webDriver, By.CssSelector("a[href='/housekeeping/lostAndFound']"));
        public IWebElement NewLostAndFoundButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'NEW LOST & FOUND ITEM']"));
        public IWebElement DescriptionInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_description']"));
        public IWebElement StatusDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_status']"));
        public IWebElement DateLostCalendarInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='dateLost']"));
        public IWebElement DateFoundCalendarInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='dateFound']"));
        public IWebElement FoundByInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_foundBy']"));
        public IWebElement PhoneDropDown(int n = 0) => Finder.By(webDriver, By.CssSelector($"#phone{n}"));
        public IWebElement CountryCodeInput => Finder.By(webDriver, By.CssSelector("input[formcontrolname='countryCode']"));
        public IWebElement PhoneNumberInput => Finder.By(webDriver, By.CssSelector("input[name='phoneNumber']"));
        public new IWebElement CreateButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE']"));



    }
}
