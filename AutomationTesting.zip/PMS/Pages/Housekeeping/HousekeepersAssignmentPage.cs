﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Housekeeping
{
    public class HousekeepersAssignmentPage : BasePage
    {
        public IWebElement HousekeepersAssignmentTab => Finder.By(webDriver, By.CssSelector("a[href='/housekeeping/housekeepersAssignment']"));

        public IWebElement AvailableHousekeepersSelectCheckBox => Finder.By(webDriver, By.CssSelector("section.table-section:nth-child(1) tr.cdk-drag"));
        public IWebElement OnDutyHousekeepersSelectCheckBox => Finder.By(webDriver, By.CssSelector("section.table-section:nth-child(3) tr.cdk-drag"));
        public IWebElement AllocateSelectedItemsButton => Finder.By(webDriver, By.CssSelector("i[ng-reflect-message='Allocate the Selected Items']"));
        public IWebElement AllocateAllButton => Finder.By(webDriver, By.CssSelector("i[ng-reflect-message='Allocate All']"));
        public IWebElement DeAllocateSelectedItemsButton => Finder.By(webDriver, By.CssSelector("i[ng-reflect-message='De-Allocate the Selected Items']"));
        public IWebElement DeAllocateAllButton => Finder.By(webDriver, By.CssSelector("i[ng-reflect-message='De-Allocate All']"));

        public IWebElement UnassignedRoomsSelectCheckBox => Finder.By(webDriver, By.CssSelector("app-assign-room mat-checkbox label.mat-checkbox-layout"));
        public IWebElement AssignButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'ASSIGN']"));
        public IWebElement ChooseHousekeepersRadioButton => Finder.By(webDriver, By.CssSelector("div.housekeeper-section div.roomDetail"));
        public IWebElement HousekeeperAssignButton => Finder.By(webDriver, By.CssSelector("section.housekeeper-wrapper button.mat-primary"));
        public IWebElement HousekeeperCancelButton => Finder.By(webDriver, By.CssSelector("section.housekeeper-wrapper button.mat-secondary"));
        public IWebElement ClearAllAssignmentButton => Finder.By(webDriver, By.XPath("//popover-content//span[normalize-space(text()) = 'Clear All Assignment']"));
        public IWebElement DeleteSelectedAssignmentButton => Finder.By(webDriver, By.XPath("//popover-content//span[normalize-space(text()) = 'Delete Selected Assignment']"));
        public IWebElement PhoneNumberInput => Finder.By(webDriver, By.CssSelector("input[name='phoneNumber']"));
        public new IWebElement CreateButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE']"));



    }
}
