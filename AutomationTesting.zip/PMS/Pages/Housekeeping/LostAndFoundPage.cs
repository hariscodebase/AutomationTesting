﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Housekeeping
{
    public class LostAndFoundPage : BasePage
    {
        public IWebElement LostAndFoundTab => Finder.By(webDriver, By.CssSelector("a[href='/housekeeping/lostAndFound']"));
        public IWebElement NewLostAndFoundButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'NEW LOST & FOUND ITEM']"));
        public IWebElement ValidateLostAndFoundItem(string columnName) => Finder.By(webDriver, By.CssSelector($"td.cdk-column-{columnName} span"));
        public IWebElement SearchCriteriaInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder*='Search Criteria']"));
        public IWebElement IncludeFoundItemsCheckBox => Finder.By(webDriver, By.CssSelector("mat-checkbox[ng-reflect-message='Include Found Items'] label"));
        public IWebElement IncludeReturnedItemsCheckBox => Finder.By(webDriver, By.CssSelector("mat-checkbox[ng-reflect-message='Include Returned Items'] label"));
        public IWebElement EditIcon => Finder.By(webDriver, By.CssSelector("button.icon-edit1"));
        public IWebElement DeleteIcon => Finder.By(webDriver, By.CssSelector("button.icon-delete"));



    }
}
