﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Accounting
{
    public class CreateAccountCategoryPage : BasePage
    {
        public IWebElement CategoryCodeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Category Code']"));
        public IWebElement CategoryDescriptionInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Category Description']"));

        
    }
}
