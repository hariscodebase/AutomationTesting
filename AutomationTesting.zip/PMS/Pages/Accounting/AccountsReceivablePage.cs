﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Accounting
{
    public class AccountsReceivablePage : BasePage 
    {
        public IWebElement AsidePanelOptions(string option) => Finder.By(webDriver, By.XPath($"//aside[@class='nav-section']//*[contains(normalize-space(text()), '{option}')]"));
        public IWebElement ShowInactiveToggleButton => Finder.By(webDriver, By.CssSelector("mat-slide-toggle[ng-reflect-id='ag-automation-toggle-showInact'] > label"));
        public IWebElement ValidateRoomSetupDetail(string columnName) => Finder.By(webDriver, By.CssSelector($"td.cdk-column-{columnName} span"));
        public IWebElement EditIcon => Finder.By(webDriver, By.CssSelector("button.icon-edit1"));
        public IWebElement DeleteIcon => Finder.By(webDriver, By.CssSelector("button.icon-delete"));
        public IWebElement CopyIcon => Finder.By(webDriver, By.CssSelector("button.icon-copy"));
        public IWebElement DragDropIcon => Finder.By(webDriver, By.CssSelector("icon-drag-drop"));
        public IWebElement CancelIcon => Finder.By(webDriver, By.CssSelector("i.icon-Cancel"));

        public IWebElement CreateARTransactionButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE A/R TRANSACTION']"));
        public IWebElement CreateAccountCategoryButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE ACCOUNT CATEGORY']"));
        public IWebElement CreateAccountCategory2Button => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE ACCOUNT CATEGORY 2']"));
        public IWebElement CreateARMiscellaneousCategory => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE A/R MISCELLANEOUS CATEGORY']"));
        public IWebElement CreateARDiscountCategory => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE A/R DISCOUNT CATEGORY']"));


    }
}
