﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Accounting
{
    public class CreateARTransactionCodePage : BasePage
    {
        public IWebElement TransactionCodeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Transaction Code']"));
        public IWebElement TransactionDescriptionTextArea => Finder.By(webDriver, By.CssSelector("textarea[formcontrolname='description']"));
        public IWebElement PostTypeDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='postType']"));

        
    }
}
