﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Accounting
{
    public class CreateAccountCategory2Page : BasePage
    {
        public IWebElement Category2CodeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Category 2 Code']"));
        public IWebElement Category2DescriptionInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Category 2 Description']"));

        
    }
}
