﻿using PMS.Pages.Common;
using System;
using System.Collections.Generic;
using System.Text;

namespace PMS.Pages.FrontDesk
{
    public class WalkInPage : BasePage
    {
    }
}
