﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PMS.Pages.FrontDesk
{
    public class FrontDeskHomePage : BasePage
    {

        public IWebElement ReservationListDetail(string columnName, int n = 0) => Finder.CollectionBy(webDriver, By.CssSelector($"td.cdk-column-{columnName} a,td.cdk-column-{columnName} span")).ElementAtOrDefault(n);

        public IWebElement InHouseRadioButton => Finder.By(webDriver, By.CssSelector("mat-radio-button[value='inHouse'] label"));
        public IWebElement GuestRecheckInRadioButton => Finder.By(webDriver, By.CssSelector("mat-radio-button[value='guestRecheckIn'] label"));


        public IWebElement RoomConditionsListDetail(string columnName, int n = 0) => Finder.CollectionBy(webDriver, By.CssSelector($"td.cdk-column-{columnName} label,td.cdk-column-{columnName} span")).ElementAtOrDefault(n);

        public IWebElement SetRoomConditionsRadioButton(string label) => Finder.By(webDriver, By.XPath($"//mat-radio-button//div[normalize-space(text())= '{label}']"));
        public IWebElement ProcessButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())='PROCESS']"));

        public IWebElement ReservationTypeCheckBox(string type) => Finder.By(webDriver, By.CssSelector($"span[title='{type}']"));
        public IWebElement RoomRackContent => Finder.By(webDriver, By.CssSelector("section[class='roomrack-content']"));
        public IWebElement RoomRackTitle => Finder.By(webDriver, By.CssSelector("section[class='roomrack-content'] h4"));
        public IWebElement RoomCell(int cellNumber = 1) => Finder.By(webDriver, By.CssSelector($"div.roomrack-row > div.roomrack-cell:nth-child({cellNumber})"));






    }
}
