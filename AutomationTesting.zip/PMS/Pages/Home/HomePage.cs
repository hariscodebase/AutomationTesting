﻿using OpenQA.Selenium;
using System;
using AgilysysTests;
using PMS.Pages.Common;
using AgilysysTests.Configurations;

namespace PMS.Pages.Home
{
    class HomePage : BasePage
    {
        public HomePage()
        {            
            try
            {
                AngularUtils.WaitUntilClickable(webDriver.FindElement(By.CssSelector("a.logo-anchor[routerlink='/home']")));
            }
            
            catch(Exception ex)
            {
                Logger.Write($"{this.ToString()} did not load within {Settings.PageTimeout} secs" + ex.ToString());
            }

            finally
            {
                Logger.Write("Exiting home page constructor");
            }
        }


        public IWebElement DashboardTitleLabel => Finder.By(webDriver, By.CssSelector("div.widget_group_title div.title"));
        public IWebElement ActivityChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,activity,']"));
        public IWebElement AverageDailyRateChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,averageDaily,']"));
        public IWebElement BestAvailableRateChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,bestAvailable,']"));
        public IWebElement WeatherChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,Weather,']"));
        public IWebElement TotalArrivalChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,totalArrival,']"));
        public IWebElement TotalDepartureChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,totalDeparture,']"));
        public IWebElement VIPChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,vipTemplate,']"));
        public IWebElement OthersChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,others,']"));
        public IWebElement TotalGuestChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,totalGuest,']"));
        public IWebElement RecentBookingsChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,recentBookings,']"));
        public IWebElement TotalRevenueWidget => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,smallWidget,']"));
        public IWebElement HousekeepingChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,houseKeeping,']"));
        public IWebElement ComplementaryRoomsChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,complimentaryRooms,']"));
        public IWebElement ROHStayChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,rOHStay,']"));
        public IWebElement ScheduleRoomMoveChart => Finder.By(webDriver, By.CssSelector("div[ng-reflect-ng-class='show,scheduleRoomMove,']"));


    }
}
