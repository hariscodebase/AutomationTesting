﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.PMSSettings
{
    public class CreateRoomTypeGroupPage : BasePage
    {
        public IWebElement RoomTypeGroupCodeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Room Type Group Code']"));
        public IWebElement RoomTypeGroupNameInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Room Type Group Name']"));
        public IWebElement RoomTypesCheckBox(string roomTypeText) => Finder.By(webDriver, By.CssSelector($"custom-checkbox span[title='{roomTypeText}']"));

    }
}
