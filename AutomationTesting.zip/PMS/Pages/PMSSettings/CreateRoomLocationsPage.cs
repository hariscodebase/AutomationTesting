﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.PMSSettings
{
    public class CreateRoomLocationsPage : BasePage
    {
        public IWebElement RoomLocationCodeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Room Location Code']"));
        public IWebElement RoomLocationNameInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Room Location Name']"));

    }
}
