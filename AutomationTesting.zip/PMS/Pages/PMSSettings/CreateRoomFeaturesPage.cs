﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.PMSSettings
{
    public class CreateRoomFeaturesPage : BasePage
    {
        public IWebElement RoomFeatureCodeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Room Feature Code']"));
        public IWebElement RoomFeatureNameInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Room Feature Name']"));        

    }
}
