﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.PMSSettings
{
    public class RoomSpecificationsPage : BasePage
    {
        public IWebElement RoomNumberInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_roomNumber']"));
        public IWebElement GenerateRoomsCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("generateRooms")));
        public IWebElement BeddedCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("bedded")));
        public IWebElement RoomTypeDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_roomType']"));
        public IWebElement BuildingDropDown => Finder.By(webDriver, By.CssSelector("mat-select[ng-reflect-name='building']"));
        public IWebElement DescriptionLabel => Finder.By(webDriver, By.XPath($"//*[normalize-space(text())= 'Description']/following-sibling::span"));
        public IWebElement NoPostRoomTaxCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("noPostRoomTax")));
        public IWebElement NumberOfBedsInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='numberOfbeds']"));
        public IWebElement NumberOfRoomsForOccInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='occTax']"));
        public IWebElement SelectAllCheckBox => Finder.By(webDriver, By.CssSelector("mat-checkbox[ng-reflect-message='Select All']"));
        public IWebElement IsCotNotAllowedCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("isCotNotAllowed")));
        public IWebElement IsCribNotAllowedCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("isCribNotAllowed")));
        public IWebElement IsSmokingCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("isSmoking")));
        public IWebElement BlockingOrderInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='blockingOrder']"));
        public IWebElement FloorNumberInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='floorNumber']"));
        public IWebElement EnergySectionCodeInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='energySectionCode']"));
        public IWebElement KeyNumberInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='keyNumber']"));
        public IWebElement PhysicalAddressTextArea => Finder.By(webDriver, By.CssSelector("textarea[formcontrolname='physicalAddress']"));
        public IWebElement FromDateInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='fromdate']"));
        public IWebElement ToDateInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='todate']"));
        

    }
}
