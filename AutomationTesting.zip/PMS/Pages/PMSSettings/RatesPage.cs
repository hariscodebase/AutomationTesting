﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.PMSSettings
{
    public class RatesPage : BasePage
    {
        public IWebElement RatesOptionsDropDown => Finder.By(webDriver, By.CssSelector("mat-select span span"));

    }
}
