﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.PMSSettings
{
    public class RoomRatePage : BasePage
    {
        public IWebElement ViewByRadioOption(string option) => Finder.By(webDriver, By.XPath($"//*[normalize-space(text())= '{option}']"));
        public IWebElement CreateRoomButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE ROOM']"));
        public IWebElement StartDateInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='startdate']"));
        public IWebElement EndDateInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='enddate']"));
        public IWebElement BuildingsDropDown => Finder.By(webDriver, By.CssSelector("mat-select[ng-reflect-name='buildings']"));
        public IWebElement RoomTypesDropDown => Finder.By(webDriver, By.CssSelector("mat-select[ng-reflect-name='roomtypes']"));
        public IWebElement SearchButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'SEARCH']"));
    }
}
