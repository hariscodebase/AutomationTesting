﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;
using System;

namespace PMS.Pages.PMSSettings
{
    public class SetUpPage : BasePage
    {
        public SetUpPage()
        {
            try
            {
                webDriverWait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("mat-select div.mat-select-trigger div.mat-select-arrow")));
            }

            catch (Exception ex)
            {
                Logger.Write($"{ToString()} did not load within 60 secs" + ex.ToString());
            }

            finally
            {
                Logger.Write(ToString());
            }
        }
        public IWebElement SetupOptionsDropDown => Finder.By(webDriver, By.CssSelector("mat-select div.mat-select-trigger div.mat-select-arrow"));
        public IWebElement AsidePanelOptions(string option) => Finder.By(webDriver, By.XPath($"//aside[@class='nav-section']//*[contains(normalize-space(text()), '{option}')]"));
        public IWebElement ShowInactiveToggleButton => Finder.By(webDriver, By.CssSelector("mat-slide-toggle[ng-reflect-id='ag-automation-toggle-showInact'] > label"));
        public IWebElement ValidateRoomSetupDetail(string columnName) => Finder.By(webDriver, By.CssSelector($"td.cdk-column-{columnName} span"));
        public IWebElement EditIcon => Finder.By(webDriver, By.CssSelector("button.icon-edit1"));
        public IWebElement DeleteIcon => Finder.By(webDriver, By.CssSelector("button.icon-delete"));
        public IWebElement CopyIcon => Finder.By(webDriver, By.CssSelector("button.icon-copy"));
        public IWebElement DragDropIcon => Finder.By(webDriver, By.CssSelector("button-drag-drop"));
        public IWebElement CancelIcon => Finder.By(webDriver, By.CssSelector("i.icon-Cancel"));

        public IWebElement CreateRoomFeatureButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE ROOM FEATURE']"));
        public IWebElement CreateRoomLocationButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE ROOM LOCATION']"));
        public IWebElement CreateRoomTypeButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE ROOM TYPE']"));
        public IWebElement CreateRoomTypeGroupButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE ROOM TYPE GROUP']"));
        public IWebElement CreateRoomButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE ROOM']"));
        
    }
}
