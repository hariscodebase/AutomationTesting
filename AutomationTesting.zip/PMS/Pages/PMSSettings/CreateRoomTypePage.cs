﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.PMSSettings
{

    public class CreateRoomTypePage : BasePage
    {
        public IWebElement RoomTypeCodeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Room Type Code']"));
        public IWebElement RoomTypeNameInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Room Type Name']"));
        public IWebElement IsNightlyCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("isNightly")));
        public IWebElement IsHourlyCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("isHourly")));
        public IWebElement SetupTimeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Setup Time']"));
        public IWebElement BreakdownTimeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Breakdown Time']"));
        public IWebElement BuildingDropDown => Finder.By(webDriver, By.CssSelector("#ag-automation-select-roomtype-building"));
        public IWebElement MinimumOccupancyInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Minimum Occupancy']"));
        public IWebElement MaximumOccupancyInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Maximum Occupancy']"));
        public IWebElement NumberOfRoomsInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Number of Rooms']"));
        public IWebElement CountAsInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Count As']"));
        public IWebElement MaximumGuestInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Maximum Guest']"));
        public IWebElement MaximumNightsInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Maximum Nights']"));

    }

}
