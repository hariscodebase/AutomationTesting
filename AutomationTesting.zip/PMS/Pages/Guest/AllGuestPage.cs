﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;
using System.Linq;

namespace PMS.Pages.Guest
{
    public class AllGuestPage : BasePage
    {
        public IWebElement AllGuestTab => Finder.By(webDriver, By.CssSelector("a[href='/guest/allGuest']"));
        public new IWebElement SearchByInput => Finder.By(webDriver, By.CssSelector("app-simple-search input"));
        public IWebElement AdvancedSearchLinkButton => Finder.By(webDriver, By.PartialLinkText("ADVANCED SEARCH"));
        public IWebElement CreateGuestButton => Finder.By(webDriver, By.XPath("//span[contains(normalize-space(text()), 'CREATE GUEST')]"));
        public IWebElement GuestListDetail(int n, string columnName) => Finder.CollectionBy(webDriver, By.CssSelector($"td.cdk-column-{columnName} span")).ElementAtOrDefault(n);
        public IWebElement GuestEditButton => Finder.By(webDriver, By.CssSelector("td.cdk-column-action button"));


    }
}
