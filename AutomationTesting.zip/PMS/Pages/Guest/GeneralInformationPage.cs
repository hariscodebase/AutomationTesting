﻿using AgilysysTests;
using AgilysysTests.Configurations;
using OpenQA.Selenium;
using PMS.Pages.Common;
using System;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;

namespace PMS.Pages.Guest
{
    public class GeneralInformationPage : BasePage
    {
        public GeneralInformationPage()
        {
            try
            {
                webDriverWait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("div.ImageUpload")));
            }

            catch (Exception ex)
            {
                Logger.Write($"{this.ToString()} did not load within {Settings.PageTimeout} secs" + ex.ToString());
            }

            finally
            {
                Logger.Write($"Exiting {this.ToString()} constructor");
            }
        }
        public IWebElement FirstNameInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_firstName']"));
        public IWebElement LastNameInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_lastName']"));
        public IWebElement InitialInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_initial']"));
        public IWebElement TitleDropDown => Finder.By(webDriver, By.CssSelector("#ag-automation-select-guestgeneralinfo-title"));
        public IWebElement CompanyNameInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_companyName']"));
        public IWebElement AliasInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_alias']"));
        public IWebElement PronouncedInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_pronounced']"));
        public IWebElement CondoOwnerCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("condoOwner")));
        public IWebElement AddressInput(int n = 0) => Finder.By(webDriver, By.CssSelector($"#AddressInput{n}"));
        public IWebElement PostalCodeInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_postalCode']"));
        public IWebElement CityInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_city']"));
        public IWebElement CountyInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_county']"));
        public IWebElement StateInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_state']"));
        public IWebElement CountryInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_country']"));
        public IWebElement PhoneDropDown(int n = 0) => Finder.By(webDriver, By.CssSelector($"#phone{n}"));
        public IWebElement CountryCodeInput => Finder.By(webDriver, By.CssSelector("input[formcontrolname='countryCode']"));
        public IWebElement PhoneNumberInput => Finder.By(webDriver, By.CssSelector("input[name='phoneNumber']"));
        public IWebElement EmailDropDown(int n = 0) => Finder.By(webDriver, By.CssSelector($"#email{n}"));
        public IWebElement EmailIdInput => Finder.By(webDriver, By.CssSelector("input[name='emailId']"));
        public IWebElement VIPDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_VIP']"));
        public IWebElement GenderDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_gender']"));
        public IWebElement JobTitleInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_jobTitle']"));
        public IWebElement NationalityDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_nationality']"));
        public IWebElement GuestTypeDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_guestType']"));
        public IWebElement OriginDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_origin']"));
        public IWebElement Segment1DropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_segment1']"));
        public IWebElement Segment2DropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_segment2']"));
        public IWebElement MarketChannelypeDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_marketChannel']"));
        public IWebElement PassportNumberInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_passportNumber']"));
        public IWebElement SocialSecurityNumberInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='Social Security Number']"));
        public IWebElement DriversLicensePlateInput => Finder.By(webDriver, By.CssSelector(@"input[data-placeholder='Driver\'s License Plate']"));
        public IWebElement PatronIdInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_patronID']"));
        public IWebElement RankInput => Finder.By(webDriver, By.CssSelector("input[literalid='lbl_rank']"));

    }
}
