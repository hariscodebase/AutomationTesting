﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Reservation
{
    public class ReservationDetailsPage : BasePage
    {
        public IWebElement ReservationStatusDropDown => Finder.By(webDriver, By.CssSelector(AgSelectors.AgDropDown("reservationStatus")));
        public IWebElement ReservationTypeRadioGroup => Finder.By(webDriver, By.CssSelector(AgSelectors.MatRadioGroup("reservationType")));
        public IWebElement PropertyDropDown => Finder.By(webDriver, By.CssSelector("app-changeproperty-dropdown mat-select"));
        public IWebElement ArrivalDateInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgDate("arrivalDate")));
        public IWebElement DepartureDateInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgDate("departureDate")));
        public IWebElement ArrivalTimeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder*='Arrival Time']"));
        public IWebElement DepartureTimeInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder*='Departure Time']"));
        public IWebElement NightsInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("nights")));
        public IWebElement HoursInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("hours")));
        public IWebElement RoomsInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("rooms")));
        public IWebElement NoOfGuestsInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("noOfGuests")));
        public IWebElement DiscChildInput => Finder.By(webDriver, By.CssSelector("input[placeholder='Disc child1']"));
        public IWebElement YouthInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("youth")));
        public IWebElement ChildInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("child")));
        public IWebElement KidInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("kid")));
        public IWebElement InfantInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("infant")));
        public IWebElement LocationsDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_locations']"));
        public IWebElement FeaturesDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_features']"));
        public new IWebElement SearchByInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgChipSearchInput("Search By")));
        public IWebElement AdvancedSearchLinkButton => Finder.By(webDriver, By.PartialLinkText("ADVANCED SEARCH"));
        public IWebElement CreateNewGuestLinkButton => Finder.By(webDriver, By.PartialLinkText("CREATE NEW GUEST"));
        public IWebElement GuestNameLabel => Finder.By(webDriver, By.CssSelector("div.info-details-wrapper div.ag_display--inblock label.ag_font--bold"));
        public IWebElement GuestGenderLabel => Finder.By(webDriver, By.CssSelector("div.info-details-wrapper div.ag_display--inblock label.ag_display--inblock"));
        public IWebElement GuestVIPIcon => Finder.By(webDriver, By.CssSelector("div.info-details-wrapper div.ag_display--inblock i.icon-vip"));
        public IWebElement GuestPhoneIcon => Finder.By(webDriver, By.CssSelector("div.info-details-wrapper i.icon-Phone"));
        public IWebElement GuestPhoneNumberLabel => Finder.By(webDriver, By.CssSelector("div.info-details-wrapper i.icon-Phone + label"));
        public IWebElement GuestEmailIcon => Finder.By(webDriver, By.CssSelector("div.info-details-wrapper i.icon-Email"));
        public IWebElement GuestEmailLabel => Finder.By(webDriver, By.CssSelector("div.info-details-wrapper i.icon-Email + label"));
        public IWebElement GuestAddressIcon => Finder.By(webDriver, By.CssSelector("div.info-details-wrapper i.icon-Address"));
        public IWebElement GuestAddressLabel => Finder.By(webDriver, By.CssSelector("div.info-details-wrapper i.icon-Address + label"));
        public IWebElement GuestEditIcon => Finder.By(webDriver, By.CssSelector("div.info-details-wrapper i[class*='icon-Edit']"));
        public IWebElement AccountNumberSearchInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgChipSearchInput("Account Number")));
        public IWebElement BookingIDSearchInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgChipSearchInput("Booking ID")));
        public IWebElement TourOperatorNumberSearchInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgChipSearchInput("Tour Operator Number")));
        public IWebElement TravelAgencyNumberInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgChipSearchInput("Travel Agency Number")));
        public IWebElement TourOperatorPayCommissionCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("tourOperatorCommissionable")));
        public IWebElement TravelAgencyPayCommissionCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("travelAgencyCommissionable")));
        public IWebElement IncludeNonBeddedCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("includeNonBeddedRoomTypes")));
        public IWebElement IncludeUnavailableRatesCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("includeUnAvailableRoomRates")));
        public IWebElement CheckAvailablilityButton => Finder.By(webDriver, By.XPath("//button/span[contains(normalize-space(text()), 'CHECK AVAILABILITY')]"));    
        public IWebElement NoOfGuestsLabel => Finder.By(webDriver, By.XPath("//label[normalize-space(text())= 'No of Guests']"));


    }
}
