﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;
using System.Linq;

namespace PMS.Pages.Reservation
{
    public class ViewReservationPage : BasePage
    {

        public IWebElement ModifyButton => Finder.By(webDriver, By.XPath("//a[contains(normalize-space(text()), 'MODIFY')]"));
        public IWebElement SearchBoxInput => Finder.By(webDriver, By.CssSelector("mat-form-field.searchbox input"));
        public IWebElement ReservedHighlightedLabel => Finder.By(webDriver, By.CssSelector("span.Reserved"));
        public IWebElement CheckedInHighlightedLabel => Finder.By(webDriver, By.CssSelector("span.CheckedIn"));
        public IWebElement CheckedOutHighlightedLabel => Finder.By(webDriver, By.CssSelector("span.CheckedOut"));

        public IWebElement RoomTariffTable => Finder.By(webDriver, By.CssSelector("table.cdk-table tbody"));
        public IWebElement ReservationActionsList(string actionName) => Finder.By(webDriver, By.XPath($"//li[normalize-space(text())= '{actionName}']"));
        public IWebElement ReservationViewDetail(string lblText) => Finder.CollectionBy(webDriver, By.XPath($"//*[contains(normalize-space(text()), '{lblText}')]/following-sibling::span")).FirstOrDefault(x=>x.Displayed);

    }
}
