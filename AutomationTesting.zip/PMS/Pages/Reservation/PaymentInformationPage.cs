﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Reservation
{
    public class PaymentInformationPage : BasePage
    {
        public IWebElement PaymentMethodDropDown => Finder.By(webDriver, By.CssSelector("#ag-automation-select-paymentmethodinfo-paymentMethod"));
        public IWebElement ReservationGuranteedCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("reservationGuranteed")));
        public IWebElement DeviceDropDown => Finder.By(webDriver, By.CssSelector("#ag-automation-select-caputurecard-device"));
        public IWebElement AccountNumberSearchInput => Finder.By(webDriver, By.CssSelector("input[placeholder='A/R Account Number']"));
        public IWebElement CreditLimitInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("creditLimit")));
        public IWebElement ChargeAccountNoInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("chargeAccountNo")));
        public IWebElement TransferToARFrequencyDropDown => Finder.By(webDriver, By.CssSelector("#ag-automation-select-paymentmethodinfo-transfertoArFrequency"));
        public IWebElement ReferralNumberInput => Finder.By(webDriver, By.CssSelector("input[placeholder='Referral Number']"));
        public IWebElement ExemptEntityInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-placeholder='Exempt Entity']"));
        public IWebElement TypeInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("type")));
        public IWebElement CategoryInput => Finder.By(webDriver, By.CssSelector(AgSelectors.AgInput("category")));
        public IWebElement OtherGuaranteeDropDown => Finder.By(webDriver, By.CssSelector("#ag-automation-select-paymentmethodinfo-otherGuarantee"));
        public IWebElement PayButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())='PAY']"));
        public IWebElement ViewEditDepositButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())='VIEW/EDIT DEPOSIT']"));

    }
}
