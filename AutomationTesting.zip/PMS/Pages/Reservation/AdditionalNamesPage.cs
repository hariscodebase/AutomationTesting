﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Reservation
{
    public class AdditionalNamesPage : BasePage
    {
        public IWebElement AddButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'Add']"));
    }
}
