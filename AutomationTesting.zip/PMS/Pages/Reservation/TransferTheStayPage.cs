﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Reservation
{
    public class TransferTheStayPage : BasePage
    {

        public IWebElement CopyGuestInfoButton => Finder.By(webDriver, By.XPath("//button/span[contains(normalize-space(text()), 'COPY GUEST INFO')]"));
        public IWebElement NewGuestButton => Finder.By(webDriver, By.XPath("//button/span[contains(normalize-space(text()), 'NEW GUEST')]"));
        public IWebElement SearchButton => Finder.By(webDriver, By.XPath("//button/span[contains(normalize-space(text()), 'SEARCH')]"));
        public IWebElement SelectGuestRadioButton => Finder.By(webDriver, By.CssSelector("td.cdk-column-selected div.radioButton label"));
        public IWebElement SelectAllCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("selectAll")));
        public IWebElement TransferEventsCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("transferEvents")));
        public IWebElement TransferTransportationReservationCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("transferTransportationReservation")));
        public IWebElement TransferGolfTeeTimesCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("transferGolfTeeTimes")));
        public IWebElement TransferSpaReservationsCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("transferSpaReservations")));
        public IWebElement TransferButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())='TRANSFER']"));

    }
}
