﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Reservation
{
    public class CheckOutPage : BasePage
    {
        public IWebElement CheckOutButton => Finder.By(webDriver, By.XPath("//button/span[contains(normalize-space(text()), 'CHECKOUT')]"));
    }
}
