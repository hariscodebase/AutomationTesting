﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Reservation
{
    public class FolioPage : BasePage
    {
        #region Tabs

        public IWebElement StatementTabButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'Statement']"));
        public IWebElement SplitDefinitionTabButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'Folio Split Definition']"));
        public IWebElement GuestInfoTabButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'Guest/Stay information']"));
        public IWebElement TransactionItemsButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'Transaction Items']"));
        public IWebElement InventoryItemsButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'Inventory Items']"));
        public IWebElement PostingTabButton => Finder.By(webDriver, By.CssSelector("mat-button-toggle[ng-reflect-value='doaPosting'] button"));
        public IWebElement MakePaymentButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'Make Payment']"));


        #endregion


        #region TransactionItems

        public IWebElement DepartmentChoose(string dept) => Finder.By(webDriver, By.XPath($"//div[@literalid='lbl_Department']/following-sibling::div/*[normalize-space(text())='{dept}']"));
        public IWebElement PostingsChoose(string posting) => Finder.By(webDriver, By.XPath($"//div[@literalid='lbl_postings']/following-sibling::div/*[normalize-space(text())='{posting}']"));
        public IWebElement AddItemButton(string itemName) => Finder.By(webDriver, By.XPath($"//span[normalize-space(text())= '{itemName}']/following-sibling::button"));
        public IWebElement BuildingDropDown => Finder.By(webDriver, By.CssSelector("mat-select[ng-reflect-placeholder='Building']"));
        public IWebElement AmountInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='amount']"));
        public IWebElement ReferenceInput => Finder.By(webDriver, By.CssSelector("input[ng-reflect-name='reference']"));
        public IWebElement PostToFolioDropDown => Finder.By(webDriver, By.CssSelector("mat-select[ng-reflect-name='folio']"));
        public IWebElement CommentsTextArea => Finder.By(webDriver, By.CssSelector("textarea[ng-reflect-name='comment']"));
        public IWebElement PaymentPopUpOkButton => Finder.By(webDriver, By.CssSelector("app-payment-popup button"));
        public IWebElement PostButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())='POST']"));

        #endregion

        #region FolioSplitDefinitionSection

        public IWebElement SetPaymentIconButton(string folioName) => Finder.By(webDriver, By.XPath($"//a[normalize-space(text())= '{folioName}']/following-sibling::span[contains((@class), 'icon-post-charges')]"));
        public IWebElement EditFolioIconButton(string folioName) => Finder.By(webDriver, By.XPath($"//a[normalize-space(text())= '{folioName}']/following-sibling::span[contains((@class), 'icon-edit')]"));
        public IWebElement AddFolioButton => Finder.By(webDriver, By.CssSelector("div.add-folio span.icon-plus"));
        public IWebElement TickIconButton => Finder.By(webDriver, By.CssSelector("div[class='border-cont'] div.inlineEditStyle i.icon-done"));
        public IWebElement CrossIconButton => Finder.By(webDriver, By.CssSelector("div[class='border-cont'] div.inlineEditStyle i.icon-Cancel"));
        public IWebElement CreditLimitLabel => Finder.By(webDriver, By.CssSelector("div.default-sect-bootom label + label"));


        public IWebElement AuthorizationAmountInput => Finder.By(webDriver, By.CssSelector("input[placeholder='Authorization Amount']"));
        public IWebElement ProcessButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())='PROCESS']"));
        public IWebElement SavePaymentMethod => Finder.By(webDriver, By.CssSelector("app-button button.ag_button--primary[ng-reflect-disabled='false']"));


        #endregion


        #region Statement

        public IWebElement StatementTableBody => Finder.By(webDriver, By.CssSelector("table#custom-theme-tableId tbody"));


        #endregion


        #region MakePayment

        public IWebElement ChooseFolioCheckBox(string folioName) => Finder.By(webDriver, By.XPath($"//h4[normalize-space(text())='{folioName}']/following-sibling::mat-checkbox"));
        public IWebElement ZipcodeInput => Finder.By(webDriver, By.CssSelector("input[formcontrolname='zipcode']"));
        public IWebElement PayButton => Finder.By(webDriver, By.CssSelector("button#proceedBtn"));
        public IWebElement ProceedWithCardPopUpYesButton => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane.small-popup button.actionButton"));


        #endregion


    }
}
