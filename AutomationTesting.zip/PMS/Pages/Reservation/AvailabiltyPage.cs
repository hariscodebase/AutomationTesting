﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Reservation
{
    public class AvailabiltyPage : BasePage
    {
        public IWebElement OccupancyPercentCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("occupancy")));
        public IWebElement LengthOfStayDaysCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("staydays")));
        public IWebElement AdvanceDaysCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("advancedays")));
        public IWebElement RoomTypeDropDown => Finder.By(webDriver, By.CssSelector("#ag-automation-select-availability-viewBy mat-select"));
        public IWebElement SearchByTariff => Finder.By(webDriver, By.CssSelector("input[data-placeholder*='Search by Tariff']"));
        public IWebElement ExpandAllCollapseAllButton => Finder.By(webDriver, By.PartialLinkText("EXPAND ALL / COLLAPSE ALL"));
        
    }
}
