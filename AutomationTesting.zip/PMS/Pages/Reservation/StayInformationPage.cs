﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Reservation
{
    public class StayInformationPage : BasePage
    {
        public IWebElement GuestCommentsTextArea => Finder.By(webDriver, By.CssSelector("textarea[formcontrolname='value']"));
        public IWebElement MarketChannelDropDown => Finder.By(webDriver, By.CssSelector("#ag-automation-select-staydetails-marketChannel"));
        public IWebElement GuestTypeHeaderSelect => Finder.By(webDriver, By.CssSelector("select.guestType_hdr"));
        public IWebElement OriginCodeHeaderSelect => Finder.By(webDriver, By.CssSelector("select.originCode_hdr"));
        public IWebElement Segment1HeaderSelect => Finder.By(webDriver, By.CssSelector("select.segment1_hdr"));
        public IWebElement Segment2HeaderSelect => Finder.By(webDriver, By.CssSelector("select.segment2_hdr"));

    }
}
