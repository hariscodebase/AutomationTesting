﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;
using System.Linq;

namespace PMS.Pages.Reservation
{
    public class ReservationsListPage : BasePage
    {

        public IWebElement SearchBoxInput => Finder.By(webDriver, By.CssSelector("mat-form-field.searchbox input"));
        public IWebElement AdvancedSearchLinkButton => Finder.By(webDriver, By.PartialLinkText("ADVANCED SEARCH"));
        public IWebElement MaximizeIcon => Finder.By(webDriver, By.CssSelector("i.icon-maximize"));
        public IWebElement LegendsIcon => Finder.By(webDriver, By.CssSelector("i.icon-legends"));
        public IWebElement FilterIcon => Finder.By(webDriver, By.CssSelector("i.icon-filter"));
        public IWebElement MinimizeIcon => Finder.By(webDriver, By.CssSelector("i.icon-minimize"));
        public IWebElement CreateReservationButton => Finder.By(webDriver, By.XPath("//span[contains(normalize-space(text()), 'CREATE RESERVATION')]"));
        public IWebElement LegendsPopoverContent => Finder.By(webDriver, By.CssSelector("#legendsPopover div.popover-body"));
        public IWebElement FilterPopoverCheckBox => Finder.By(webDriver, By.XPath("//popover-content[@id='FilterPopover']"));
        public IWebElement ReservationListDetail(string columnName, int n = 0) => Finder.CollectionBy(webDriver, By.CssSelector($"td.cdk-column-{columnName} a,td.cdk-column-{columnName} span")).ElementAtOrDefault(n);

    }
}
