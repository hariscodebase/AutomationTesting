﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Reservation
{
    public class CheckInPage : BasePage
    {

        private IWebElement CheckInSection => Finder.By(webDriver, By.XPath("//section[@class='reservation-checkin']"));
        public IWebElement ReservationViewDetail(string lblText) => Finder.By(CheckInSection, By.XPath($"//*[normalize-space(text())= '{lblText}']/following-sibling::span"));

        public IWebElement AllBuildingTypesToggleButton => Finder.By(webDriver, By.CssSelector("#ag-automation-toggle-allBuildingTypes"));
        public IWebElement AllRoomTypesToggleButton => Finder.By(webDriver, By.CssSelector("#ag-automation-toggle-allRoomTypes"));
        public IWebElement RoomFilterRadioButton(string radioLabel) => Finder.By(webDriver, By.XPath($"//div[normalize-space(text())= '{radioLabel}']"));
        public IWebElement BuildingDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_building']"));
        public IWebElement RoomTypeDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_roomType']"));
        public IWebElement LocationsDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_locations']"));
        public IWebElement FeaturesDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_features']"));
        public IWebElement ExactMatchFeatureCheckBox => Finder.By(webDriver, By.CssSelector("mat-checkbox[literalid='lbl_exactMatchFeature']"));
        public IWebElement IncludeSmokingCheckBox => Finder.By(webDriver, By.CssSelector("mat-checkbox[literalid='lbl_inclSmokingNonSmoking']"));
        public IWebElement ShowListButton => Finder.By(webDriver, By.XPath("//span[normalize-space(text())= 'SHOW LIST']"));
        public IWebElement ResetButton => Finder.By(webDriver, By.XPath("//span[normalize-space(text())= 'RESET']"));
        public IWebElement RoomNumberSelect(string roomNum) => Finder.By(webDriver, By.XPath($"//span[normalize-space(text())= '{roomNum}']"));
        public IWebElement RequestKeyInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder*='Request Key']"));
        public IWebElement PopUpGenerateKeyButton => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane button.ag_button--primary"));
        public IWebElement CheckInButton => Finder.By(webDriver, By.XPath("//button/span[contains(normalize-space(text()), 'CHECK IN')]"));


    }
}
