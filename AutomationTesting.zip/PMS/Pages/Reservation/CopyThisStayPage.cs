﻿using AgilysysTests;
using OpenQA.Selenium;
using PMS.Pages.Common;

namespace PMS.Pages.Reservation
{
    public class CopyThisStayPage : BasePage
    {

        public IWebElement CopyGuestInfoButton => Finder.By(webDriver, By.XPath("//button/span[contains(normalize-space(text()), 'COPY GUEST INFO')]"));
        public IWebElement NewGuestButton => Finder.By(webDriver, By.XPath("//button/span[contains(normalize-space(text()), 'NEW GUEST')]"));
        public IWebElement RoomTypeDropDown => Finder.By(webDriver, By.CssSelector("mat-select[literalid='lbl_roomType']"));
        public IWebElement SelectAllCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("checkAll")));
        public IWebElement CopyGuaranteeCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("copyGuarantee")));
        public IWebElement CopyAllocationsCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("copyAllocations")));
        public IWebElement CopyRecurringChargesCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("copyRecurringCharges")));
        public IWebElement CopyPostingDefinitionsCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("copyPostingDefinitions")));
        public IWebElement CopyTaxExemptionsCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("copyTaxExemptions")));
        public IWebElement SetAsShareCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("setAsShare")));
        public IWebElement CopyButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())='COPY']"));

    }
}
