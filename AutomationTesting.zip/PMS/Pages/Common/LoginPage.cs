﻿using OpenQA.Selenium;
using AgilysysTests;

namespace PMS.Pages.Common
{
    public class LoginPage : BasePage
    {
        public IWebElement LoginLabel => Finder.By(webDriver, By.CssSelector("label[literalid='login']"));
        public IWebElement UserNameInput => Finder.By(webDriver, By.CssSelector("input[formcontrolname='userId']"));
        public IWebElement PasswordInput => Finder.By(webDriver, By.CssSelector("input[formcontrolname='password']"));
        public IWebElement CustomerIdInput => Finder.By(webDriver, By.CssSelector("input[formcontrolname='customerId']"));
        public IWebElement RememberMeCheckBox => Finder.By(webDriver, By.CssSelector("mat-checkbox[formcontrolname='rememberme'] > label"));
        public IWebElement LoginButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'Login']"));
        public IWebElement LocationSelect => Finder.By(webDriver, By.CssSelector("mat-select[formcontrolname='location']"));
        public IWebElement EnterButton => LoginButton;

    }
}
