﻿using AgilysysTests;
using AgilysysTests.Common;
using AgilysysTests.Configurations;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;

namespace PMS.Pages.Common
{
    public abstract class BasePage
    {
        public IWebDriver webDriver;
        public WebDriverWait webDriverWait => new WebDriverWait(webDriver, TimeSpan.FromSeconds(Settings.ElementTimeout));
        public BasePage()
        {
            webDriver = WebDriver.Driver;
        }


        public IWebElement DotsButton => Finder.By(webDriver, By.CssSelector("i.icon-filled-more"));
        public IWebElement DotsHorizontalButton => Finder.By(webDriver, By.CssSelector("i.icon-More-Actions"));
        public IWebElement HomeTab => Finder.By(webDriver, By.CssSelector("a[href='/home']"));
        public IWebElement FrontDeskTab => Finder.By(webDriver, By.CssSelector("a[href='/frontdesk']"));
        public IWebElement ReservationsTab => Finder.By(webDriver, By.CssSelector("a[href='/reservations']"));
        public IWebElement GuestTab => Finder.By(webDriver, By.CssSelector("a[href='/guest']"));
        public IWebElement HousekeepingTab => Finder.By(webDriver, By.CssSelector("a[href='/housekeeping']"));
        public IWebElement AccountingTab => Finder.By(webDriver, By.CssSelector("a[href='/accounting']"));
        public IWebElement SettingsTab => Finder.By(webDriver, By.CssSelector("a[href='/settings']"));
        public IWebElement ReportsTab => Finder.By(webDriver, By.CssSelector("a[href='/reports']"));
        public IWebElement GroupsTab => Finder.By(webDriver, By.CssSelector("a[href='/groups']"));        
        public IWebElement ReservationDetailsTab => Finder.By(webDriver, By.XPath("//span[contains(normalize-space(text()), 'RESERVATION DETAILS')]"));
        public IWebElement AvailabilityTab => Finder.By(webDriver, By.XPath("//span[contains(normalize-space(text()), 'AVAILABILITY')]"));
        public IWebElement StayInformationTab => Finder.By(webDriver, By.XPath("//span[contains(normalize-space(text()), 'STAY INFORMATION')]"));
        public IWebElement PaymentInformationTab => Finder.By(webDriver, By.XPath("//span[contains(normalize-space(text()), 'PAYMENT INFORMATION')]"));
        public IWebElement BookButton => Finder.By(webDriver, By.XPath("//button/span[contains(normalize-space(text()), 'BOOK')]"));
        public IWebElement CancelButton => Finder.By(webDriver, By.XPath("//app-button//span[contains(normalize-space(text()), 'CANCEL')]"));
        public IWebElement ContinueButton => Finder.By(webDriver, By.XPath("//app-button//span[contains(normalize-space(text()), 'CONTINUE')]"));
        public IWebElement SaveButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'SAVE']"));
        public IWebElement SaveAndCloseButton => Finder.By(webDriver, By.XPath("//app-button//span[contains(normalize-space(text()), 'SAVE & CLOSE')]"));
        public IWebElement UpdateButton => Finder.By(webDriver, By.XPath("//app-button//span[contains(normalize-space(text()), 'UPDATE')]"));
        public IWebElement NextButton => Finder.By(webDriver, By.XPath("//button/span[contains(normalize-space(text()), 'NEXT')]"));
        public IWebElement SearchByInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder*='Search by']"));
        public IWebElement SubmoduleTabText(string tabText) => Finder.By(webDriver, By.CssSelector($"//a[normalize-space(text())='{tabText}']"));
        public IWebElement SectionTitleHeader => Finder.By(webDriver, By.CssSelector("div.create-header-sect > h4"));
        public IWebElement SectionBackButton => Finder.By(webDriver, By.CssSelector("div.create-header-sect > h4 > i"));
        public IWebElement CreateButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'CREATE']"));
        public IWebElement FinishButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'FINISH']"));
        public IWebElement PreviousButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'PREVIOUS']"));
        public IWebElement ListOrderInput => Finder.By(webDriver, By.CssSelector("input[data-placeholder='List Order']"));
        public IWebElement IsActiveCheckBox => Finder.By(webDriver, By.CssSelector(AgSelectors.MatCheckBox("isActive")));
        public IWebElement NoDataFoundLabel => Finder.By(webDriver, By.CssSelector("span[literalid='lbl_noDataFound']"));
        public IWebElement SetupOptionsDropDown => Finder.By(webDriver, By.CssSelector("mat-select div.mat-select-trigger div.mat-select-arrow"));
        public IWebElement LoginButton => Finder.By(webDriver, By.XPath("//button/span[normalize-space(text())= 'Login']"));
        public IWebElement LinkText(string linkText) => Finder.By(webDriver, By.LinkText(linkText));



        #region PopUpWebElements

        public IWebElement PopUpMessage => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane.small-popup div.pop-message"));
        public IWebElement PopUpYesButton => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane.small-popup button.ag_button--primary"));
        public IWebElement PopUpOkButton => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane.small-popup button.ag_button--primary"));
        public IWebElement PopUpContinueButton => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane.small-popup button.ag_button--primary"));
        public IWebElement PopUpNoButton => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane.small-popup button.ag_button--secondary"));
        public IWebElement PopUpCloseButton => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane span.dialog-container__header--close"));
        public IWebElement PopUpConfirmationIcon => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane.small-popup i.icon-confirmed"));
        public IWebElement PopUpInfoIcon => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane.small-popup i.icon-warning-icon"));
        public IWebElement PopUpInfoOkButton => Finder.By(webDriver, By.CssSelector("div.cdk-overlay-pane.small-popup button.button--primary"));


        #endregion

        #region Reservation-ConfirmationPopUp

        private IWebElement ConfirmationPopUpBox()
        {
            WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(Settings.ElementTimeout));
            var ele = wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("section.confirmation-popup-wrapper")));
            return ele;
        }

        public IWebElement ConfirmationNumberLabel => Finder.By(ConfirmationPopUpBox(), By.CssSelector("label[literalid='lbl_confirmationpopNumber'] + div > span"));
        public IWebElement ConfirmationPopUpDetails(string literalID) => Finder.By(ConfirmationPopUpBox(), By.CssSelector($"label[literalid='{literalID}'] + span"));
        #endregion


        #region AccountingTabs

        public IWebElement AccountsReceivableTab => Finder.By(webDriver, By.CssSelector("a[href='/accounting/accountsreceivable']"));
        public IWebElement CustomerMaintenanceTab => Finder.By(webDriver, By.CssSelector("a[href='/accounting/receivable']"));
        public IWebElement ARTraceMaintenanceTab => Finder.By(webDriver, By.CssSelector("a[href='/accounting/traceMaintenance']"));
        public IWebElement CreditCardPaymentTab => Finder.By(webDriver, By.CssSelector("a[href='/accounting/creditcardpayment']"));
        public IWebElement PaymentMaintenanceTab => Finder.By(webDriver, By.CssSelector("a[href='/accounting/paymentmaintenance']"));
        public IWebElement DisputedTransactionsTab => Finder.By(webDriver, By.CssSelector("a[href='/accounting/disputedtransactions']"));
        public IWebElement TransactionMaintenanceTab => Finder.By(webDriver, By.CssSelector("a[href='/accounting/transactionmaintenance']"));
        public IWebElement InvoicesTab => Finder.By(webDriver, By.CssSelector("a[href='/accounting/invoices']"));

        #endregion

        #region FrontDeskTabs

        public IWebElement CheckInTab => Finder.By(webDriver, By.CssSelector("a[href='/frontdesk/checkin']"));
        public IWebElement WalkInTab => Finder.By(webDriver, By.CssSelector("a[href='/frontdesk/walkin']"));
        public IWebElement PostActionsTab => Finder.By(webDriver, By.CssSelector("a[href='/frontdesk/postactions']"));
        public IWebElement CheckOutTab => Finder.By(webDriver, By.CssSelector("a[href='/frontdesk/checkout']"));
        public IWebElement RoomSectionsTab => Finder.By(webDriver, By.CssSelector("a[href='/frontdesk/roomsections']"));
        public IWebElement GuestActionsTab => Finder.By(webDriver, By.CssSelector("a[href='/frontdesk/guestactions']"));
        public IWebElement HouseStatusTab => Finder.By(webDriver, By.CssSelector("a[href='/frontdesk/housestatus']"));
        public IWebElement RoomRackTab => Finder.By(webDriver, By.CssSelector("a[href='/frontdesk/roomrack']"));

        #endregion

        /// <summary>
        /// Holds ag-components returns ag-generic-cssSelectors
        /// </summary>
        public static class AgSelectors
        {
            public static string AgDropDown(string formControlName) => $"ag-dropdown[formcontrolname='{formControlName}']";
            public static string AgDate(string formControlName) => $"ag-date[formcontrolname='{formControlName}']";
            public static string AgInput(string formControlName) => $"ag-input[formcontrolname='{formControlName}'] input";
            public static string AgChipSearchInput(string placeHolderName) => $"app-chip-search input[placeholder*='{placeHolderName}']";
            public static string MatRadioGroup(string formControlName) => $"mat-radio-group[formcontrolname='{formControlName}']";
            public static string MatCheckBox(string formControlName) => $"mat-checkbox[formcontrolname='{formControlName}'] label";

        }
        
    }
}
