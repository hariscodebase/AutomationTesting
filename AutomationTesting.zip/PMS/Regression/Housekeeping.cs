﻿using NUnit.Framework;
using AgilysysTests;
using PMS.Scripts;

namespace PMS.Regression
{
    [TestFixture]
    public class Housekeeping : BaseNunitInitialize
    {

        [Test]
        [Category("Housekeeping")]
        public void CreateEditDeleteLostItem()
        {
            AddReport();

            HousekeepingScripts housekeepingScripts = new HousekeepingScripts();
            housekeepingScripts.LoginPMS();
            string itemName = "AUTOTEST";
            housekeepingScripts.CreateLostFoundItem(itemName, "Lost");
            housekeepingScripts.EditLostFoundItem(itemName);
            housekeepingScripts.DeleteLostFoundItem(itemName);

        }

        //[Test]
        //[Category("Housekeeping")]
        //public void CreateEditDeleteFoundItem()
        //{
        //    AddReport();

        //    HousekeepingScripts housekeepingScripts = new HousekeepingScripts();
        //    housekeepingScripts.LoginPMS();
        //    string itemName = "AUTOTEST";
        //    housekeepingScripts.CreateLostFoundItem(itemName, "Found");
        //    housekeepingScripts.EditLostFoundItem(itemName);
        //    housekeepingScripts.DeleteLostFoundItem(itemName);

        //}

        [Test]
        [Category("Housekeeping")]
        public void AssignHousekeepers()
        {
            AddReport();

            HousekeepingScripts housekeepingScripts = new HousekeepingScripts();
            housekeepingScripts.LoginPMS();
            housekeepingScripts.AssignHousekeepersToRoom();

        }



    }
}
