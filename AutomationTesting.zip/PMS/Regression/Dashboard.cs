﻿using NUnit.Framework;
using AgilysysTests;
using PMS.Scripts;

namespace PMS.Regression
{
    [TestFixture]
    public class Dashboard : BaseNunitInitialize
    {

        [Test]
        [Category("Dashboard")]
        public void ViewDashboard()
        {
            AddReport();

            DashboardScripts dashboardScripts = new DashboardScripts();
            dashboardScripts.LoginPMS();
            dashboardScripts.DashboardView();
        }

       
    }
}
