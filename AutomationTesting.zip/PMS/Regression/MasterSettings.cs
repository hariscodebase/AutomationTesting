﻿using NUnit.Framework;
using AgilysysTests;
using PMS.Scripts;

namespace PMS.Regression
{
    [TestFixture]
    public class MasterSettings : BaseNunitInitialize
    {
        [Test]
        [Category("Settings")]
        public void CreateEditDeleteRoomFeature()
        {
            AddReport();

            SettingsScripts settingsScripts = new SettingsScripts();
            settingsScripts.LoginPMS();
            string roomFeatureCode = "AUTO";
            settingsScripts.CreateRoomFeature(roomFeatureCode);
            settingsScripts.EditRoomFeature(roomFeatureCode);
            settingsScripts.DeleteRoomFeature(roomFeatureCode);
        }

        [Test]
        [Category("Settings")]
        public void CreateEditDeleteRoomLocation()
        {
            AddReport();

            SettingsScripts settingsScripts = new SettingsScripts();
            settingsScripts.LoginPMS();
            string roomLocationCode = "AUTO";
            settingsScripts.CreateRoomLocation(roomLocationCode);
            settingsScripts.EditRoomLocation(roomLocationCode);
            settingsScripts.DeleteRoomLocation(roomLocationCode);
        }

        [Test]
        [Category("Settings")]
        public void CreateEditDeleteRoomType()
        {
            AddReport();

            SettingsScripts settingsScripts = new SettingsScripts();
            settingsScripts.LoginPMS();
            string roomTypeCode = "AUTO";
            settingsScripts.CreateRoomType(roomTypeCode);
            settingsScripts.EditRoomType(roomTypeCode);
            settingsScripts.DeleteRoomType(roomTypeCode);
        }

        [Test]
        [Category("Settings")]
        public void CreateEditDeleteRoomTypeGroup()
        {
            AddReport();

            SettingsScripts settingsScripts = new SettingsScripts();
            settingsScripts.LoginPMS();
            string roomTypeCode = "AUTO";
            settingsScripts.CreateRoomTypeGroup(roomTypeCode);
            settingsScripts.EditRoomTypeGroup(roomTypeCode);
            settingsScripts.DeleteRoomTypeGroup(roomTypeCode);
        }
    }
}
