﻿using NUnit.Framework;
using AgilysysTests;
using PMS.Scripts;

namespace PMS.Regression
{
    [TestFixture]
    public class PMSApiTests : BaseNunitInitialize
    {

        [Test]
        [Category("PMSApiTests")]
        public void CreateEditDeleteLostItem()
        {
            AddReport();

            ApiTestScripts apiTestScripts = new ApiTestScripts();
            

        }

        



    }
}
