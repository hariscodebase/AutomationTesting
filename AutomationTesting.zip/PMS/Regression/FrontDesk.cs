﻿using NUnit.Framework;
using AgilysysTests;
using PMS.Scripts;

namespace PMS.Regression
{
    [TestFixture]
    public class FrontDesk : BaseNunitInitialize
    {

        ApiTestScripts apiTestScripts = new ApiTestScripts();

        [Test]
        [Category("FrontDesk")]
        public void FrontDeskWalkIn()
        {
            AddReport();

            FrontDeskScripts frontDeskScripts = new FrontDeskScripts();
            frontDeskScripts.LoginPMS();
            frontDeskScripts.NavigateToFrontDesk();
            frontDeskScripts.WalkIn();
        }


        [Test]
        [Category("FrontDesk")]
        public void FrontDeskCheckIn()
        {
            AddReport();

            FrontDeskScripts frontDeskScripts = new FrontDeskScripts();
            frontDeskScripts.LoginPMS();
            frontDeskScripts.NavigateToFrontDesk();
            frontDeskScripts.CheckIn();
        }


        [Test]
        [Category("FrontDesk")]
        public void FrontDeskPostActions()
        {
            AddReport();

            FrontDeskScripts frontDeskScripts = new FrontDeskScripts();
            frontDeskScripts.LoginPMS();
            frontDeskScripts.NavigateToFrontDesk();
            string confirmationNumber = apiTestScripts.CreateReservationViaApi();
            frontDeskScripts.PostActions(confirmationNumber);
        }

        [Test]
        [Category("FrontDesk")]
        public void FrontDeskCheckOut()
        {
            AddReport();

            FrontDeskScripts frontDeskScripts = new FrontDeskScripts();
            frontDeskScripts.LoginPMS();
            frontDeskScripts.NavigateToFrontDesk();
            frontDeskScripts.CheckOut();
        }


        [Test]
        [Category("FrontDesk")]
        public void FrontDeskSetRoomConditions()
        {
            AddReport();

            FrontDeskScripts frontDeskScripts = new FrontDeskScripts();
            frontDeskScripts.LoginPMS();
            frontDeskScripts.NavigateToFrontDesk();
            frontDeskScripts.SetRoomConditions();
        }


        [Test]
        [Category("FrontDesk")]
        public void FrontDeskRoomRack()
        {
            AddReport();

            FrontDeskScripts frontDeskScripts = new FrontDeskScripts();
            frontDeskScripts.LoginPMS();
            frontDeskScripts.NavigateToFrontDesk();
            frontDeskScripts.ProcessRoomRack();
        }


    }
}
