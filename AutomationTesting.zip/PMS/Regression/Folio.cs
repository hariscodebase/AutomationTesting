﻿using NUnit.Framework;
using AgilysysTests;
using PMS.Scripts;
using AgilysysTests.Configurations;

namespace PMS.Regression
{
    [TestFixture]
    public class Folio : BaseNunitInitialize
    {
        ApiTestScripts apiTestScripts = new ApiTestScripts();

        [Test]
        [Category("Folio")]
        public void CreateFolio()
        {
            AddReport();

            FolioScripts folioScripts = new FolioScripts();
            folioScripts.LoginPMS();
            string reservationNumber = apiTestScripts.CreateReservationViaApi();
            folioScripts.CreateFolio(reservationNumber);

        }

        [Test]
        [Category("SmokeTest")]
        public void SetPaymentAndMakePayment()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            FolioScripts folioScripts = new FolioScripts();
            folioScripts.LoginPMS();
            string guestName = Settings.Environment.Equals("QAINT") ? "folio folio" : "Hari Dinesh";
            string reservationNumber = reservationScripts.CreateReservation(guestName);
            folioScripts.SetPaymentMethod(reservationNumber);
            folioScripts.FolioPosting();
            folioScripts.MakePayment();
        }

        [Test]
        [Category("Folio")]
        public void FolioPostingAndVerifyStatement()
        {
            AddReport();

            ReservationScripts reservationScripts = new ReservationScripts();
            FolioScripts folioScripts = new FolioScripts();
            folioScripts.LoginPMS();
            string confirmationNumber = apiTestScripts.CreateReservationViaApi();
            reservationScripts.FolioPosting(confirmationNumber);
            folioScripts.VerifyFolioStatement(confirmationNumber);
        }

    }
}
