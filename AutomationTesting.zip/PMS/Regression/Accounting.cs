﻿using NUnit.Framework;
using AgilysysTests;
using PMS.Scripts;

namespace PMS.Regression
{
    [TestFixture]
    public class Accounting : BaseNunitInitialize
    {
        
        [Test]
        [Category("Accounting")]
        public void CreateEditDeleteARAccountCategory()
        {
            AddReport();

            AccountingScripts accountingScripts = new AccountingScripts();
            accountingScripts.LoginPMS();
            accountingScripts.NavigateToAccounting();
            string code = "TEST";
            accountingScripts.CreateARAccountCategory(code);
            accountingScripts.EditARAccountCategory(code);
            accountingScripts.DeleteARAccountCategory(code);
        }

        [Test]
        [Category("Accounting")]
        public void CreateEditDeleteARAccountCategory2()
        {
            AddReport();

            AccountingScripts accountingScripts = new AccountingScripts();
            accountingScripts.LoginPMS();
            accountingScripts.NavigateToAccounting();
            string code = "TEST";
            accountingScripts.CreateARAccountCategory2(code);
            accountingScripts.EditARAccountCategory2(code);
            accountingScripts.DeleteARAccountCategory2(code);
        }

        [Test]
        [Category("Accounting")]
        public void CreateEditDeleteARMiscellaneousCategory()
        {
            AddReport();

            AccountingScripts accountingScripts = new AccountingScripts();
            accountingScripts.LoginPMS();
            accountingScripts.NavigateToAccounting();
            string code = "TEST";
            accountingScripts.CreateARMiscellaneousCategory(code);
            accountingScripts.EditARMiscellaneousCategory(code);
            accountingScripts.DeleteARMiscellaneousCategory(code);
        }

        [Test]
        [Category("Accounting")]
        public void CreateEditDeleteARDiscountCategory()
        {
            AddReport();

            AccountingScripts accountingScripts = new AccountingScripts();
            accountingScripts.LoginPMS();
            accountingScripts.NavigateToAccounting();
            string code = "TEST";
            accountingScripts.CreateARDiscountCategory(code);
            accountingScripts.EditARDiscountCategory(code);
            accountingScripts.DeleteARDiscountCategory(code);
        }


    }
}
