﻿using AgilysysTests.Common;
using AgilysysTests.Configurations;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;

namespace AgilysysTests
{
    public class AngularUtils
    {
        
        public static void WaitForLoader()
        {
            WebDriverWait wait = new WebDriverWait(WebDriver.Driver, TimeSpan.FromSeconds(Settings.ElementTimeout));
            wait.Until(ExpectedConditions.ElementExists(By.CssSelector("div#cover-spin[style='display: none;']")));
        }

        public static void WaitUntilClickable(IWebElement ele)
        {
            WebDriverWait wait = new WebDriverWait(WebDriver.Driver, TimeSpan.FromSeconds(Settings.ElementTimeout));
            wait.Until(ExpectedConditions.ElementToBeClickable(ele));
        }

        /// <summary>
        /// Waits for the page to load
        /// </summary>
        public static void PageHasLoaded()
        {
            var wait = new WebDriverWait(WebDriver.Driver, TimeSpan.FromMilliseconds(Settings.PageTimeout));            
            wait.Until(d => ((IJavaScriptExecutor)d).ExecuteScript("return document.readyState").Equals("complete"));
        }


    }
}
