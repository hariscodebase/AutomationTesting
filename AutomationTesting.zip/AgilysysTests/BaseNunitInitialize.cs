﻿using AgilysysTests.Common;
using AgilysysTests.Configurations;
using AventStack.ExtentReports;
using AventStack.ExtentReports.Reporter;
using NUnit.Framework;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Edge;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;

namespace AgilysysTests
{

    public class BaseNunitInitialize
    {
        public IWebDriver webDriver = WebDriver.Driver;
        public static ExtentReports _extent;
        public static ExtentTest _test;
        public static Dictionary<string, string> dictionary = new Dictionary<string, string>();
        public string TC_Name;
        public string projectPath, logPath, reportPath;

        [SetUp]
        public void Setup()
        {
            Logger.CreateLogFile(logPath);
            Logger.Write("*****Test Exectution Started****");

            SetUpBrowser();

        }

        [OneTimeSetUp]
        public void ExtentStart()
        {
            AppConfigReader.SetupFramework();
            projectPath = TestContext.CurrentContext.TestDirectory; //GetProjectPath();
            logPath = projectPath.ToString() + Settings.LogPath + string.Format("{0:yyyymmddhhmmssss}", DateTime.Now) + "\\";
            Directory.CreateDirectory(logPath);
            reportPath = logPath + "Index.html";

            var htmlReporter = new ExtentHtmlReporter(reportPath);
            _extent = new ExtentReports();
            _extent.AttachReporter(htmlReporter);
            _extent.AddSystemInfo("Host Name", "Automated Run");
            _extent.AddSystemInfo("Environment", Settings.Environment);
            _extent.AddSystemInfo("UserName", "PMSADMIN");
            htmlReporter.LoadConfig(projectPath + @"\report-config.xml");
        }




        private void SetUpBrowser()
        {
            switch (Settings.Browser)
            {
                case BrowserType.Firefox:
                    WebDriver.Driver = new FirefoxDriver();
                    break;

                case BrowserType.Chrome:
                    var localChromeOptions = new ChromeOptions();
                    localChromeOptions.AddArguments(new string[] { "no-sandbox" });


                    var serverChromeOptions = new ChromeOptions();
                    serverChromeOptions.AddArguments(new List<string>() { "headless", "window-size=1920,1080"});

                    var serverName = System.Net.Dns.GetHostEntry(Environment.MachineName).HostName;
                    Logger.Write(serverName);

                    var chromeDriverPath = Directory.GetCurrentDirectory() + @"\WebDrivers";
                    WebDriver.Driver = serverName.Contains("ad.local") ?
                        new ChromeDriver(ChromeDriverService.CreateDefaultService(), localChromeOptions, TimeSpan.FromSeconds(Settings.PageTimeout))
                        : new ChromeDriver(ChromeDriverService.CreateDefaultService(), serverChromeOptions, TimeSpan.FromSeconds(Settings.PageTimeout));
                    break;

                case BrowserType.Edge:
                    WebDriver.Driver = new EdgeDriver();
                    break;

                default:
                    WebDriver.Driver = new ChromeDriver();
                    break;
            }
            WebDriver.Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(Settings.ElementTimeout);
            Logger.Write("New Window size : " + WebDriver.Driver.Manage().Window.Size);
            WebDriver.Driver.Manage().Window.Maximize();
            Logger.Write("Maximized Window size : " + WebDriver.Driver.Manage().Window.Size);
            WebDriver.Driver.Manage().Cookies.DeleteAllCookies();

        }

        [TearDown]
        public void CleanUpRun()
        {
            Logger.Write("****Test Execution Completed****");

            var exec_status = TestContext.CurrentContext.Result.Outcome.Status;
            var stacktrace = string.IsNullOrEmpty(TestContext.CurrentContext.Result.StackTrace) ? ""
            : string.Format("{0}", TestContext.CurrentContext.Result.StackTrace);
            Status logstatus = Status.Pass;
            String fileName;

            DateTime time = DateTime.Now;
            fileName = "Screenshot_" + time.ToString("HH_mm_ss_") + TestContext.CurrentContext.Test.Name + ".png";

            switch (exec_status)
            {
                case TestStatus.Failed:
                    logstatus = Status.Fail;
                    Capture(WebDriver.Driver, fileName);
                    var mediaEntity = CaptureScreenShot(WebDriver.Driver, fileName);
                    _test.Log(Status.Fail, "Fail");
                    _test.Fail("ExtentReport 4 Capture: Test Failed", mediaEntity);
                    _test.Log(Status.Fail, "Traditional Snapshot below: " + _test.AddScreenCaptureFromPath(fileName));
                    break;

                case TestStatus.Passed:
                    logstatus = Status.Pass;
                    Capture(WebDriver.Driver, fileName);
                    mediaEntity = CaptureScreenShot(WebDriver.Driver, fileName);
                    _test.Log(Status.Pass, "Pass");
                    _test.Pass("ExtentReport 4 Capture: Test Passed", mediaEntity);
                    _test.Log(Status.Pass, "Traditional Snapshot below: " + _test.AddScreenCaptureFromPath(fileName));
                    break;

                case TestStatus.Inconclusive:
                    logstatus = Status.Warning;
                    break;

                case TestStatus.Skipped:
                    logstatus = Status.Skip;
                    break;

                default:
                    break;
            }

            TestContext.AddTestAttachment(logPath + fileName);
            TestContext.AddTestAttachment(Logger.logFilePath);
            _test.Log(logstatus, "Test: " + TC_Name + " Status:" + logstatus + stacktrace);
            dictionary.Clear();
            WebDriver.Driver.Dispose();
            WebDriver.Driver.Quit();
            _extent.Flush();
            TestContext.AddTestAttachment(reportPath);
            KillChromeDriverExes();

        }

        public void Capture(IWebDriver driver, String screenShotName)
        {
            ITakesScreenshot ts = (ITakesScreenshot)driver;
            Screenshot screenshot = ts.GetScreenshot();
            var finalpth = logPath + screenShotName;
            var localpath = new Uri(finalpth).LocalPath;
            screenshot.SaveAsFile(localpath, ScreenshotImageFormat.Png);
        }

        public MediaEntityModelProvider CaptureScreenShot(IWebDriver driver, String screenShotName)
        {
            ITakesScreenshot ts = (ITakesScreenshot)driver;
            var screenshot = ts.GetScreenshot().AsBase64EncodedString;

            return MediaEntityBuilder.CreateScreenCaptureFromBase64String(screenshot, screenShotName).Build();
        }

        public void AddReport()
        {
            string context_name = TestContext.CurrentContext.Test.Name + " on " + Settings.Browser + " " + Settings.Environment;
            TC_Name = context_name;
            _test = _extent.CreateTest(context_name);
        }

        public string GetProjectPath()
        {
            var path = TestContext.CurrentContext.TestDirectory;
            var actualPath = path.Substring(0, path.LastIndexOf("bin"));
            var projectPath = new Uri(actualPath).LocalPath;
            return projectPath;
        }

        public void KillChromeDriverExes()
        {
            Process[] chromeDriverProcesses = Process.GetProcessesByName("chromedriver");
            foreach (var chromeDriverProcess in chromeDriverProcesses)
            {
                chromeDriverProcess.Kill();
            }
        }
    }
}
