﻿using Microsoft.Extensions.Configuration;
using System.IO;

namespace AgilysysTests.Configurations
{
    public class AppConfigReader 
    {
        public static void SetupFramework()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json");

            IConfigurationRoot configurationRoot = builder.Build();

            string environment = configurationRoot.GetValue<string>("Environment");

            Settings.Browser = configurationRoot.GetSection(environment).Get<TestSettings>().Browser;
            Settings.TestType = configurationRoot.GetSection(environment).Get<TestSettings>().TestType;
            Settings.Environment = configurationRoot.GetSection(environment).Get<TestSettings>().Environment;
            Settings.PMSUrl = configurationRoot.GetSection(environment).Get<TestSettings>().PMSUrl;
            Settings.PmsGatewayURL = configurationRoot.GetSection(environment).Get<TestSettings>().PmsGatewayURL;
            Settings.TenantURL = configurationRoot.GetSection(environment).Get<TestSettings>().TenantURL;
            Settings.SynxisUrl = configurationRoot.GetSection(environment).Get<TestSettings>().SynxisUrl;
            Settings.Username = configurationRoot.GetSection(environment).Get<TestSettings>().Username;
            Settings.Password = configurationRoot.GetSection(environment).Get<TestSettings>().Password;
            Settings.CustomerId = configurationRoot.GetSection(environment).Get<TestSettings>().CustomerId;
            Settings.PageTimeout = configurationRoot.GetSection(environment).Get<TestSettings>().PageTimeout;
            Settings.ElementTimeout = configurationRoot.GetSection(environment).Get<TestSettings>().ElementTimeout;
            //Settings.PropertyDate = configurationRoot.GetSection(environment).Get<TestSettings>().PropertyDate;
            Settings.LogPath = configurationRoot.GetSection(environment).Get<TestSettings>().LogPath;

        }
        
    }
}
