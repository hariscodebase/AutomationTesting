﻿namespace AgilysysTests.Configurations
{
    public class Settings
    {
        public static BrowserType Browser { get; set; }
        public static string TestType { get; set; }
        public static string Environment { get; set; }
        public static string PMSUrl { get; set; }
        public static string PmsGatewayURL { get; set; }
        public static string TenantURL { get; set; }
        public static string SynxisUrl { get; set; }
        public static string Username { get; set; }
        public static string Password { get; set; }
        public static string CustomerId { get; set; }
        public static int PageTimeout { get; set; }
        public static int ElementTimeout { get; set; }
        public static string PropertyDate { get; set; }
        public static string LogPath { get; set; }

    }
}
