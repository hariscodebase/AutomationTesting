﻿using Newtonsoft.Json;

namespace AgilysysTests.Configurations
{

    public class TestSettings
    {
        [JsonProperty("browser")]
        public BrowserType Browser { get; set; }


        [JsonProperty("testtype")]
        public string TestType { get; set; }


        [JsonProperty("environment")]
        public string Environment { get; set; }


        [JsonProperty("pmsURL")]
        public string PMSUrl { get; set; }


        [JsonProperty("pmsGatewayURL")]
        public string PmsGatewayURL { get; set; }


        [JsonProperty("tenantURL")]
        public string TenantURL { get; set; }


        [JsonProperty("synxisURL")]
        public string SynxisUrl { get; set; }


        [JsonProperty("username")]
        public string Username { get; set; }


        [JsonProperty("password")]
        public string Password { get; set; }


        [JsonProperty("customerId")]
        public string CustomerId { get; set; }


        [JsonProperty("pageTimeout")]
        public int PageTimeout { get; set; }


        [JsonProperty("elementTimeout")]
        public int ElementTimeout { get; set; }


        [JsonProperty("propertyDate")]
        public string PropertyDate { get; set; }


        [JsonProperty("logPath")]
        public string LogPath { get; set; }

    }
}
