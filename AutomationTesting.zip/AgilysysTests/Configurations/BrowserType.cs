﻿namespace AgilysysTests.Configurations
{
    public enum BrowserType
    {
        Firefox,
        Chrome,
        Edge
    }
}
