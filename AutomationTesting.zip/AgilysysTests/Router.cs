﻿using OpenQA.Selenium;
using System;
using AgilysysTests.Common;
using OpenQA.Selenium.Interactions;
using System.Linq;
using OpenQA.Selenium.Support.UI;
using System.Collections.Generic;

namespace AgilysysTests
{
    public class Router
    {
        public static void Click(IWebElement webElement)
        {
            webElement.Click();
            AngularUtils.WaitForLoader();
        }

        public static void ClickByJS(IWebElement webElement)
        {
            IJavaScriptExecutor executor = (IJavaScriptExecutor)WebDriver.Driver;
            executor.ExecuteScript("arguments[0].click();", webElement);
        }

        public static void ClickByActions(IWebElement webElement)
        {
            Actions actions = new Actions(WebDriver.Driver);
            actions.MoveToElement(webElement).Click().Perform();
        }

        public static void Sendkeys(IWebElement webElement, string key)
        {            
            webElement.SendKeys(Keys.Control + "a");
            webElement.SendKeys(key);
            AngularUtils.WaitForLoader();
        }

        public static void DropDownSelect(IWebElement element, string value, bool isContains = true)
        {
            Click(element);
            IWebElement selectElement 
                = Finder.By(WebDriver.Driver, By.XPath( !isContains ? $"//mat-option//*[normalize-space(text())='{value}']" : $"//mat-option//*[contains(normalize-space(text()), '{value}')]"));
            Click(selectElement);
        }

        public static void DropDownSelect(IWebElement element, int n)
        {
            Click(element);
            IWebElement selectElement
                = Finder.CollectionBy(WebDriver.Driver, By.CssSelector($"mat-option span.mat-option-text")).ElementAtOrDefault(n);
            Click(selectElement);
        }

        public static void Select(IWebElement element, string value)
        {
            SelectElement selectElement = new SelectElement(element);
            selectElement.SelectByText(value, true);
        }

        public static void Select(IWebElement element, int n)
        {
            SelectElement selectElement = new SelectElement(element);
            selectElement.SelectByIndex(n);
        }

        public static void CheckBoxDropDownSelect(IWebElement element, string[] values)
        {
            Click(element);
            IWebElement selectElement;
            foreach (var value in values)
            {
                selectElement = Finder.By(WebDriver.Driver, By.XPath($"//span[normalize-space(text())='{value}']"));
                Click(selectElement);
            }
            IWebElement transparentOverlayElement = Finder.By(WebDriver.Driver, By.CssSelector("div[class='cdk-overlay-container']"));
            Router.Click(transparentOverlayElement);
        }

        public static void CheckBoxPopOverSelect(IWebElement webElement, string value)
        {
            IWebElement checkBoxElement =
                Finder.By(webElement, By.XPath($"//div[@class='popover-body']//*[normalize-space(text())='{value}']"));
            Click(checkBoxElement);
        }

        public static void RadioButtonSelect(IWebElement webElement, string value, bool isContains = true)
        {
            IWebElement radioGroupElement =
                Finder.By(webElement, By.XPath( !isContains ? $"//mat-radio-button//*[normalize-space(text())='{value}']/../../label" : $"//mat-radio-button//*[contains(normalize-space(text()), '{value}')]/../../label"));
            Click(radioGroupElement);
        }

        public static void SearchAndSelect(IWebElement element, string searchKey, string selectValue)
        {
            Router.Sendkeys(element, searchKey);
            IWebElement selectElement = Finder.By(WebDriver.Driver, By.XPath($"//mat-option//*[normalize-space(text())='{selectValue}']"));
            Click(selectElement);
        }

        public static void SearchAndSelect(IWebElement element, string searchKey, int n)
        {
            Router.Sendkeys(element, searchKey);
            Click(element);
            IWebElement selectElement = Finder.CollectionBy(WebDriver.Driver, By.CssSelector("div.pac-item")).ElementAtOrDefault(n);
            Click(selectElement);
        }

        public static void DatePicker(IWebElement webElement, DateTime date)
        {
            IWebElement calenderButton = Finder.By(webElement, By.TagName("button"));
            Click(calenderButton);            
            IWebElement calendarPeriodButton 
                = Finder.By(WebDriver.Driver, By.CssSelector("div[class='cdk-overlay-container'] mat-datepicker-content button.mat-calendar-period-button"));
            Click(calendarPeriodButton);
            IWebElement year
                = Finder.By(WebDriver.Driver, By.XPath($"//div[@class='cdk-overlay-container']//*[normalize-space(text())='{date.Year}']"));
            Click(year);
            IWebElement month
                = Finder.By(WebDriver.Driver, By.XPath($"//div[@class='cdk-overlay-container']//*[normalize-space(text())='{date.ToString("MMM").ToUpper()}']"));
            Click(month);
            IWebElement day
                = Finder.By(WebDriver.Driver, By.XPath($"//div[@class='cdk-overlay-container']//*[normalize-space(text())='{date.Day}']"));
            Click(day);

        }

        public static void TimePicker(IWebElement webElement, DateTime time)
        {
            Click(webElement);
            IWebElement hours
                = Finder.By(WebDriver.Driver, By.XPath($"//ngx-material-timepicker-container//*[normalize-space(text())='{time.TimeOfDay.Hours}']"));
            Click(hours);
            IWebElement minutes
                = Finder.By(WebDriver.Driver, By.XPath($"//ngx-material-timepicker-minutes-face//*[normalize-space(text())='{time.ToString("mm")}']"));

            ClickByActions(minutes);
            
            IWebElement day
                = Finder.By(WebDriver.Driver, By.XPath($"//ngx-material-timepicker-container//*[normalize-space(text())='{time.ToString("tt")}']"));
            Click(day);

            IWebElement okayBtn
                = Finder.By(WebDriver.Driver, By.CssSelector($"ngx-material-timepicker-container button[literalid='btn_ok']"));
            Click(okayBtn);
        }

        public static void TablePicker(string expandKey, string rowKey, int value)
        {
            // Commenting the below as Expand Collapse buttons were introduced.
            IWebElement expandCollapseButton = Finder.By(WebDriver.Driver, By.PartialLinkText("EXPAND ALL / COLLAPSE ALL"));
            List<IWebElement> expandedSections = Finder.CollectionBy(WebDriver.Driver, By.CssSelector("tr.accord-header"));
            foreach (var expandedSection in expandedSections)
            {
                if (expandedSection.GetAttribute("class").Contains("row-expanded"))
                {
                    Router.Click(expandCollapseButton);
                    Router.Click(expandCollapseButton);
                    break;
                }
                
            }

            IWebElement expandElement = Finder.CollectionBy(WebDriver.Driver, By.CssSelector("tr.accord-header"))
                .FirstOrDefault(x => x.Text.Contains(expandKey));
            Click(expandElement);

            IWebElement rowIdentifier = Finder.CollectionBy(WebDriver.Driver, By.CssSelector("tr[class='accord-body ng-star-inserted']"))
                .FirstOrDefault(x => x.Text.Contains(rowKey));

            IWebElement colIdentifier = Finder.CollectionBy(rowIdentifier, By.CssSelector("tr[class='accord-body ng-star-inserted'] mat-radio-button + span"))
                .ElementAtOrDefault(value);
            Click(colIdentifier);


        }

    }
}
