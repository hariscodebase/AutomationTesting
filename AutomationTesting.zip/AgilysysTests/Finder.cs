﻿using AgilysysTests.Configurations;
using AventStack.ExtentReports;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace AgilysysTests
{
    public static class Finder 
    {
        private static string findEleLog = string.Empty;
        private static WebDriverWait webDriverWait;

        public static IWebElement By(IWebDriver webDriver, By locator)
        {
            StackTrace stackTrace = new StackTrace();
            var sFrame = stackTrace.GetFrame(1).GetMethod();
            string appName = sFrame.DeclaringType.FullName.Split('.').First();
            string pageName = sFrame.DeclaringType.FullName.Split('.').Last();
            string fieldName = sFrame.ToString().Contains('_') ? sFrame.Name.Split('_')[1] : sFrame.Name;
            webDriverWait = new  WebDriverWait(webDriver, TimeSpan.FromSeconds(Settings.ElementTimeout));
            AngularUtils.WaitForLoader();


            try
            {
                webDriverWait.Until(ExpectedConditions.ElementToBeClickable(locator));
                IWebElement ele = webDriver.FindElement(locator);
                findEleLog = $"Element Found: {appName} | {pageName} | {fieldName} - {locator.ToString()}";
                return ele;
            }
            catch (Exception ex)
            {
                findEleLog = $"Issue finding the element: {appName} | {pageName} | {fieldName} - Exception msg: {ex.Message}";
                throw ex;
            }
            finally
            {
                Logger.Write(findEleLog);
                BaseNunitInitialize._test.Log(findEleLog.Contains("Issue") ? Status.Fail : Status.Pass, findEleLog);
            }
            
        }

        public static IWebElement By(IWebElement webElement, By locator)
        {
            StackTrace stackTrace = new StackTrace();
            var sFrame = stackTrace.GetFrame(1).GetMethod();
            string appName = sFrame.DeclaringType.FullName.Split('.').First();
            string pageName = sFrame.DeclaringType.FullName.Split('.').Last();
            string fieldName = sFrame.ToString().Contains('_') ? sFrame.Name.Split('_')[1] : sFrame.Name;
            AngularUtils.WaitForLoader();

            try
            {
                IWebElement ele = webElement.FindElement(locator);
                findEleLog = $"Element Found: {appName} | {pageName} | {fieldName} - {locator.ToString()}";
                return ele;
            }
            catch (Exception ex)
            {
                findEleLog = $"Issue finding the element: {appName} | {pageName} | {fieldName} - Exception msg: {ex.Message}";
                throw ex;
            }
            finally
            {
                Logger.Write(findEleLog);
                BaseNunitInitialize._test.Log(findEleLog.Contains("Issue") ? Status.Fail : Status.Pass, findEleLog);
            }

        }

        public static List<IWebElement> CollectionBy(IWebDriver webDriver, By locator)
        {
            StackTrace stackTrace = new StackTrace();
            var sFrame = stackTrace.GetFrame(1).GetMethod();
            string appName = sFrame.DeclaringType.FullName.Split('.').First();
            string pageName = sFrame.DeclaringType.FullName.Split('.').Last();
            string fieldName = sFrame.ToString().Contains('_') ? sFrame.Name.Split('_')[1] : sFrame.Name;
            webDriverWait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(Settings.ElementTimeout));
            AngularUtils.WaitForLoader();

            try
            {
                webDriverWait.Until(ExpectedConditions.ElementToBeClickable(locator));
                List<IWebElement> ele = webDriver.FindElements(locator).ToList();
                findEleLog = $"Element Found: {appName} | {pageName} | {fieldName} - {locator.ToString()}";
                return ele;
            }
            catch (Exception ex)
            {
                findEleLog = $"Issue finding the element: {appName} | {pageName} | {fieldName} - Exception msg: {ex.Message}";
                throw ex;
            }
            finally
            {
                Logger.Write(findEleLog);
                BaseNunitInitialize._test.Log(findEleLog.Contains("Issue") ? Status.Fail : Status.Pass, findEleLog);
            }

        }

        public static List<IWebElement> CollectionBy(IWebElement webElement, By locator)
        {
            StackTrace stackTrace = new StackTrace();
            var sFrame = stackTrace.GetFrame(1).GetMethod();
            string appName = sFrame.DeclaringType.FullName.Split('.').First();
            string pageName = sFrame.DeclaringType.FullName.Split('.').Last();
            string fieldName = sFrame.ToString().Contains('_') ? sFrame.Name.Split('_')[1] : sFrame.Name;
            AngularUtils.WaitForLoader();

            try
            {
                List<IWebElement> ele = webElement.FindElements(locator).ToList();
                findEleLog = $"Element Found: {appName} | {pageName} | {fieldName} - {locator.ToString()}";
                return ele;
            }
            catch (Exception ex)
            {
                findEleLog = $"Issue finding the element: {appName} | {pageName} | {fieldName} - Exception msg: {ex.Message}";
                throw ex;
            }
            finally
            {
                Logger.Write(findEleLog);
                BaseNunitInitialize._test.Log(findEleLog.Contains("Issue") ? Status.Fail : Status.Pass, findEleLog);
            }

        }
    }
}
