﻿using NUnit.Framework;
using System;
using System.IO;

namespace AgilysysTests
{
    public class Logger
    {
        private static StreamWriter _streamWriter = null;

        public static string logFilePath { get; set; }

        public static void CreateLogFile(string logPath)
        {
            logFilePath = logPath + TestContext.CurrentContext.Test.Name + " " + DateTime.Now.ToString("T").Replace(':', '_') + ".log";
            Directory.CreateDirectory(logPath);
            _streamWriter = File.AppendText(logFilePath);
        }

        public static void Write(string logMsg)
        {
            _streamWriter.WriteLine($"{DateTime.Now.ToLongTimeString()} {DateTime.Now.ToLongDateString()} - {logMsg}");
            _streamWriter.Flush();
        }
    }
}
