﻿using AgilysysTests;
using AgilysysTests.Configurations;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using ExpectedConditions = SeleniumExtras.WaitHelpers.ExpectedConditions;
using AgilysysTests.Common;

namespace OTAIntegration.Pages
{
    public class SearchReservationsPage : BasePage
    {
        public SearchReservationsPage()
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(Settings.ElementTimeout));
                wait.Until(ExpectedConditions.ElementToBeClickable(By.CssSelector("#Logo")));
            }

            catch (Exception ex)
            {
                Logger.Write($"{this.ToString()} did not load within 60 secs" + ex.ToString());
            }
            finally
            {
                Logger.Write($"Exiting {this.ToString()} constructor");
            }

        }

        public IWebElement SearchType => Finder.By(WebDriver.Driver, By.CssSelector("select[id*='searchTypeDropDown']"));
        public IWebElement SearchNumber => Finder.By(webDriver, By.CssSelector("input[id*='PMSConfirmTextBox']"));
        public IWebElement SearchButton => Finder.By(webDriver, By.CssSelector("input[id*='SearchPMSConfirmButton']"));
        public IWebElement SearchResultsGrid => Finder.By(webDriver, By.CssSelector("table[id*='ReservationListDataGrid']"));
        public IWebElement SourceValue => Finder.By(webDriver, By.CssSelector("td[valign='top']:nth-child(5)"));
        public IWebElement NameValue => Finder.By(webDriver, By.CssSelector("td[valign='top']:nth-child(9)"));
    }
}
