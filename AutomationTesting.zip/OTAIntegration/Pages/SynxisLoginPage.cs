﻿using AgilysysTests;
using OpenQA.Selenium;

namespace OTAIntegration.Pages
{
    public class SynxisLoginPage : BasePage
    {
        public IWebElement UserNameInput => Finder.By(webDriver, By.Id("LoginCntrl_UsernameTextBox"));
        public IWebElement PasswordInput => Finder.By(webDriver, By.Id("LoginCntrl_PasswordTextBox"));
        public IWebElement SignInButton => Finder.By(webDriver, By.Id("LoginCntrl_LoginButton"));

    }
}
