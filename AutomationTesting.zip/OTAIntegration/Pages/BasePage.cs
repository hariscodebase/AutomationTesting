﻿using AgilysysTests;
using AgilysysTests.Common;
using OpenQA.Selenium;

namespace OTAIntegration.Pages
{
    public class BasePage
    {
        public IWebDriver webDriver;
        
        public BasePage()
        {
            webDriver = WebDriver.Driver;
        }

        public IWebElement frameElement => Finder.By(webDriver, By.Id("ContentIframe"));

        public IWebElement ManageLinkButton => Finder.By(webDriver, By.CssSelector("a[navid='200016']"));
        public IWebElement ReservationsButton => Finder.By(webDriver, By.CssSelector("a[navid='200018']"));
        public IWebElement SearchReservationsButton => Finder.By(webDriver, By.CssSelector("div.thrdLvl a[navid='201088']"));
    }
}
