using AgilysysTests;
using AgilysysTests.Common;
using AgilysysTests.Configurations;
using NUnit.Framework;
using OTAIntegration.Pages;
using PMS.Scripts;
using System;

namespace OTAIntegration
{
    public class UITests : BaseNunitInitialize
    {
        [Test]
        public void VerifyReservationsFromPMSToOTA()
        {
            var reservationScripts = new ReservationScripts();
            reservationScripts.LoginPMS();
            var pmsConfirmationNumber = reservationScripts.CreateReservation();

            AddReport();

            WebDriver.Driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(120);
            WebDriver.Driver.Navigate().GoToUrl(Settings.SynxisUrl);
            
            var synxisLoginPage = new SynxisLoginPage();
            synxisLoginPage.UserNameInput.SendKeys("VISONEADMINCERT");
            synxisLoginPage.PasswordInput.SendKeys("V1sualOne!");
            synxisLoginPage.SignInButton.Click();

            var searchReservationsPage = new SearchReservationsPage();
            Router.ClickByJS(searchReservationsPage.ManageLinkButton);
            Router.ClickByJS(searchReservationsPage.ReservationsButton);
            Router.ClickByJS(searchReservationsPage.SearchReservationsButton);

            WebDriver.Driver.SwitchTo().Frame(searchReservationsPage.frameElement);

            Router.Select(searchReservationsPage.SearchType, "PMS Confirmation Number");
            searchReservationsPage.SearchNumber.SendKeys(pmsConfirmationNumber);
            searchReservationsPage.SearchButton.Click();
            bool isResultsDisplayed = searchReservationsPage.SearchResultsGrid.Displayed;
            Logger.Write(isResultsDisplayed ? "PMS Reservation Displayed in Synxis" : "PMS Reservation NOT Reflected in Synxis");

            WebDriver.Driver.SwitchTo().ParentFrame();
        }
    }
}